const fs = require('fs');
const path = require('path');

const usersPath = path.join(__dirname, 'users.json');

// Initialize users database
let users = {};
try {
  users = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
} catch {
  users = {};
}

function saveUsers() {
  fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), 'utf8');
}

/**
 * Get or create user data
 * @param {number} chatId - Telegram chat ID
 * @param {object} userInfo - Optional user info from ctx.from
 * @returns {object} User data
 */
function getUser(chatId, userInfo = null) {
  const id = String(chatId);
  
  if (!users[id]) {
    users[id] = {
      chatId: chatId,
      username: userInfo?.username || null,
      firstName: userInfo?.first_name || null,
      lastName: userInfo?.last_name || null,
      balance: 0,
      transactions: [],
      createdAt: new Date().toISOString(),
      lastActive: new Date().toISOString()
    };
    saveUsers();
  } else {
    // Update user info and last active
    if (userInfo) {
      users[id].username = userInfo.username || users[id].username;
      users[id].firstName = userInfo.first_name || users[id].firstName;
      users[id].lastName = userInfo.last_name || users[id].lastName;
    }
    users[id].lastActive = new Date().toISOString();
    saveUsers();
  }
  
  return users[id];
}

/**
 * Get user balance
 * @param {number} chatId - Telegram chat ID
 * @returns {number} User balance
 */
function getBalance(chatId) {
  const user = getUser(chatId);
  return user.balance || 0;
}

/**
 * Add balance to user
 * @param {number} chatId - Telegram chat ID
 * @param {number} amount - Amount to add
 * @param {string} note - Transaction note
 * @returns {object} Updated user data
 */
function addBalance(chatId, amount, note = 'Add balance') {
  const user = getUser(chatId);
  user.balance = (user.balance || 0) + amount;
  
  user.transactions = user.transactions || [];
  user.transactions.push({
    type: 'ADD',
    amount: amount,
    note: note,
    balanceAfter: user.balance,
    createdAt: new Date().toISOString()
  });
  
  saveUsers();
  return user;
}

/**
 * Reduce balance from user
 * @param {number} chatId - Telegram chat ID
 * @param {number} amount - Amount to reduce
 * @param {string} note - Transaction note
 * @returns {object} Updated user data or null if insufficient balance
 */
function reduceBalance(chatId, amount, note = 'Reduce balance') {
  const user = getUser(chatId);
  
  if ((user.balance || 0) < amount) {
    return null; // Insufficient balance
  }
  
  user.balance = user.balance - amount;
  
  user.transactions = user.transactions || [];
  user.transactions.push({
    type: 'REDUCE',
    amount: amount,
    note: note,
    balanceAfter: user.balance,
    createdAt: new Date().toISOString()
  });
  
  saveUsers();
  return user;
}

/**
 * Set user balance (admin only)
 * @param {number} chatId - Telegram chat ID
 * @param {number} amount - New balance amount
 * @param {string} note - Transaction note
 * @returns {object} Updated user data
 */
function setBalance(chatId, amount, note = 'Set balance by admin') {
  const user = getUser(chatId);
  const oldBalance = user.balance || 0;
  user.balance = amount;
  
  user.transactions = user.transactions || [];
  user.transactions.push({
    type: 'SET',
    amount: amount,
    oldBalance: oldBalance,
    note: note,
    balanceAfter: user.balance,
    createdAt: new Date().toISOString()
  });
  
  saveUsers();
  return user;
}

/**
 * Get all users (for broadcast)
 * @returns {array} Array of user objects
 */
function getAllUsers() {
  return Object.values(users);
}

/**
 * Get user count
 * @returns {number} Number of users
 */
function getUserCount() {
  return Object.keys(users).length;
}

/**
 * Get user transactions
 * @param {number} chatId - Telegram chat ID
 * @param {number} limit - Number of transactions to return
 * @returns {array} Array of transaction objects
 */
function getTransactions(chatId, limit = 10) {
  const user = getUser(chatId);
  const transactions = user.transactions || [];
  return transactions.slice(-limit).reverse();
}

module.exports = {
  getUser,
  getBalance,
  addBalance,
  reduceBalance,
  setBalance,
  getAllUsers,
  getUserCount,
  getTransactions,
  saveUsers
};

