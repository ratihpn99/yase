# 💵 Top Up / Deposit Saldo Documentation

## 🎯 Overview

The bot now supports **TWO** methods for users to top up their balance:

1. **🤝 Via Admin** - Manual transfer with admin approval (NO FEES!)
2. **⚡ Via QRIS** - Automatic instant top-up (with small fees)

---

## 🚀 Features Implemented

### For Users:
- ✅ **Top Up Menu** - New "💵 Top Up Saldo" button on main menu
- ✅ **Dual Options** - Choose between Admin or QRIS
- ✅ **Real-time Status** - Get instant notifications
- ✅ **Transaction History** - All top-ups tracked
- ✅ **Info Page** - Detailed guide on how to top up

### For Admins:
- ✅ **Top Up Requests Panel** - View all pending requests
- ✅ **One-Click Approval** - Approve/reject with buttons
- ✅ **Auto Notifications** - Get notified of new requests
- ✅ **User Details** - See full user info before approving
- ✅ **Statistics** - Track pending requests count

---

## 📱 USER GUIDE

### How to Top Up (2 Methods)

#### Method 1: 🤝 Via Admin (FREE - No Fees!)

**Steps:**
1. Click "💵 Top Up Saldo" from main menu
2. Click "🤝 Via Admin"
3. Enter amount (minimum Rp10.000)
   - Example: `50000`
4. Wait for admin to provide bank account
5. Transfer to the account
6. Upload proof of transfer (optional)
7. Admin approves → Balance added instantly!

**Advantages:**
- ❌ NO FEES
- ✅ Manual verification (safe)
- ⏱️ Processing: 1-10 minutes

**Example Flow:**
```
User: 50000
Bot: ✅ Request sent! Request ID: REQ_123456

Admin will provide bank account details.
Please transfer Rp50.000 and wait for approval.
```

---

#### Method 2: ⚡ Via QRIS (INSTANT!)

**Steps:**
1. Click "💵 Top Up Saldo" from main menu
2. Click "⚡ Via QRIS (Otomatis)"
3. Enter amount (minimum Rp10.000)
   - Example: `100000`
4. Scan QR Code that appears
5. Pay with any e-wallet (GoPay, OVO, DANA, etc.)
6. Balance added AUTOMATICALLY!

**Advantages:**
- ⚡ INSTANT (no waiting!)
- ✅ Automatic verification
- 🔄 Works 24/7
- 💳 Accept all e-wallets

**Fees:**
- **Service fee**: 0.7% + Rp200
- Example: Top up Rp100.000 → Pay Rp100.900

**Example Flow:**
```
User: 100000

Bot sends:
╔═══════════════════════╗
║  TOP UP VIA QRIS ⚡
╚═══════════════════════╝

┌───────────────────────┐
│ • Jumlah Top Up: Rp100.000
│ • Biaya Admin: Rp900
│ • Total Bayar: Rp100.900
└───────────────────────┘

[QR CODE IMAGE]

💳 Scan QR Code untuk membayar
⚡ Saldo masuk OTOMATIS!
```

---

### Comparison Table

| Feature | Via Admin 🤝 | Via QRIS ⚡ |
|---------|--------------|------------|
| **Fees** | **FREE** ✅ | 0.7% + Rp200 |
| **Speed** | 1-10 min ⏱️ | **Instant** ⚡ |
| **Availability** | Office hours | **24/7** 🕐 |
| **Min Amount** | Rp10.000 | Rp10.000 |
| **Payment Method** | Bank Transfer | Any e-wallet |
| **Verification** | Manual | **Automatic** |

---

## 👑 ADMIN GUIDE

### Viewing Top Up Requests

**Access:**
```
/admin → 💳 Top Up Requests
```

**Display:**
```
💳 TOP UP REQUESTS

Total: 3 permintaan

1. John Doe
   ID: 123456789
   Jumlah: Rp50.000
   Waktu: 27 Oktober 2025 14:30
   @johndoe
   Request ID: REQ_123456

2. Jane Smith
   ID: 987654321
   Jumlah: Rp100.000
   Waktu: 27 Oktober 2025 14:25
   Request ID: REQ_789012
```

---

### Processing Requests

**Click on a request to see details:**

```
💳 DETAIL TOP UP REQUEST

User: John Doe
Username: @johndoe
Chat ID: 123456789
Jumlah: Rp50.000
Status: pending
Waktu: 27 Oktober 2025 14:30

Rekening untuk transfer:
BRI: 1234567890
BCA: 0987654321

Kirim rekening ini ke user dan tunggu bukti transfer.

[✅ Approve] [❌ Reject]
[📞 Contact User]
[⬅️ Kembali]
```

---

### Approving a Request

**Steps:**
1. View request details
2. Verify user transferred correctly
3. Click "✅ Approve"
4. Balance added automatically
5. User receives notification

**What happens:**
- ✅ Balance credited to user
- 📧 User gets notification
- 📊 Transaction recorded
- ✅ Request marked as approved

**User receives:**
```
✅ TOP UP BERHASIL!

Saldo Anda telah ditambahkan:
Jumlah: Rp50.000
Saldo baru: Rp150.000

Terima kasih telah melakukan top up! 🎉
```

---

### Rejecting a Request

**Steps:**
1. View request details
2. Click "❌ Reject"
3. User receives notification

**User receives:**
```
❌ TOP UP DITOLAK

Permintaan top up Anda sebesar Rp50.000 ditolak.

Silakan hubungi admin untuk informasi lebih lanjut.
```

---

### Admin Notifications

**When user creates request, all admins receive:**
```
🔔 TOP UP REQUEST BARU

User: John Doe
@johndoe
Chat ID: 123456789
Jumlah: Rp50.000
Request ID: REQ_123456

Gunakan /admin untuk memproses.
```

---

## 🔧 Technical Details

### Data Structures

**Manual Top Up Request:**
```javascript
{
  requestId: "REQ_1234567890_abc123",
  chatId: 123456789,
  username: "johndoe",
  firstName: "John",
  lastName: "Doe",
  amount: 50000,
  status: "pending", // pending | approved | rejected
  createdAt: "2025-10-27T14:30:00.000Z",
  processedAt: "2025-10-27T14:35:00.000Z" // when approved/rejected
}
```

**QRIS Top Up:**
```javascript
{
  msgIds: Set([12345, 67890]), // Messages to delete after payment
  chatId: 123456789,
  ref: "TOPUP_1234567890_abc123",
  reff_id: "atlantic_ref_123",
  amount: 100000, // User receives
  totalCharge: 100900, // User pays (with fees)
  serviceFee: 900,
  createdAt: "2025-10-27T14:30:00.000Z",
  expiresAt: "2025-10-27T14:35:00.000Z" // 5 minutes TTL
}
```

---

### Payment Flow

#### Manual (Via Admin):
```
User → Enter Amount
  ↓
Create Request
  ↓
Notify Admins
  ↓
User Transfers
  ↓
Admin Approves
  ↓
Add Balance
  ↓
Notify User ✅
```

#### QRIS (Automatic):
```
User → Enter Amount
  ↓
Calculate Fees
  ↓
Create QRIS Invoice (Atlantic API)
  ↓
Show QR Code
  ↓
User Scans & Pays
  ↓
Atlantic Webhook/Polling
  ↓
Auto Add Balance
  ↓
Delete QR Messages
  ↓
Notify User ✅
```

---

### Polling System

**Interval:** Every 5 seconds

**QRIS Top Up Polling:**
- Check payment status via Atlantic API
- If PAID → Add balance, notify user
- If EXPIRED/CANCELLED → Clean up, notify user
- Auto-cancel after 5 minutes

---

## 📊 Statistics

### Admin Panel Shows:
- **Total Pending Requests** - Real-time count
- **Request History** - All approved/rejected
- **User Details** - Full info per request

---

## 🎁 Benefits

### For Users:
1. **Choice** - Pick what suits you best
2. **Flexibility** - Bank or e-wallet
3. **Transparency** - Clear fees shown
4. **Speed** - QRIS for urgent needs
5. **Savings** - Admin route for no fees

### For Business:
1. **Automated** - QRIS auto-processes
2. **Scalable** - Handle many requests
3. **Tracked** - All transactions recorded
4. **Revenue** - Earn from QRIS fees
5. **Control** - Admin approval for manual

---

## ⚙️ Configuration

### Minimum Amount
Change in `src/_bot.js`:
```javascript
if (isNaN(amount) || amount < 10000) {
  return ctx.reply('❌ Jumlah tidak valid. Minimum Rp10.000');
}
```

### Fees (QRIS only)
Already configured:
```javascript
const FEE_PERCENT = 0.007;  // 0.7%
const FEE_FIXED = 200;      // Rp200
```

### Payment Timeout
Already configured:
```javascript
const PAYMENT_TTL_MS = 5 * 60 * 1000; // 5 minutes
```

---

## 🆘 Troubleshooting

### User Issues

**"Jumlah tidak valid"**
- Amount must be numeric
- Minimum Rp10.000
- Don't use dots or commas

**"Invoice tidak ditemukan"**
- QR Code expired (5 min limit)
- Request new QR Code

**"Top up ditolak"**
- Contact admin for reason
- Check transfer amount/account

### Admin Issues

**"Request tidak ditemukan"**
- Request already processed
- Refresh admin panel

**QRIS not working**
- Check Atlantic API credentials
- Check internet connection
- Verify Atlantic API key in `.env`

---

## 💡 Tips & Best Practices

### For Users:
1. **Use QRIS for urgent** - Instant credit
2. **Use Admin to save fees** - If time allows
3. **Double check amount** - Before sending
4. **Keep proof of transfer** - For admin method

### For Admins:
1. **Verify transfers** - Check bank statements
2. **Respond quickly** - Better user experience
3. **Keep records** - Screenshot approvals
4. **Update bank info** - Keep it current

---

## 📝 Customization

### Change Bank Account Info
Edit in `src/_bot.js` at line ~896:
```javascript
text += `\n*Rekening untuk transfer:*\n` +
  `BRI: 1234567890 a.n. Your Name\n` +
  `BCA: 0987654321 a.n. Your Name\n\n`;
```

### Add More Payment Methods
Add buttons in top-up menu:
```javascript
const kb = Markup.inlineKeyboard([
  [Markup.button.callback('🤝 Via Admin', 'TOPUP_MANUAL')],
  [Markup.button.callback('⚡ Via QRIS', 'TOPUP_QRIS')],
  [Markup.button.callback('💳 Via VA Bank', 'TOPUP_VA')], // New!
  [Markup.button.callback('❓ Cara Top Up', 'TOPUP_INFO')]
]);
```

---

## 🎉 Success!

Your bot now has a complete **dual top-up system**! Users can choose between:
- 🤝 **Manual (Free)** - Admin approval
- ⚡ **QRIS (Instant)** - Automatic

Both methods are fully integrated with:
- Balance management
- Transaction history
- Real-time notifications
- Admin controls

**Happy topping up!** 💰

