# 📦 Bulk CRUD Features Documentation

## ✨ Overview

Sistem bulk/massal CRUD telah ditambahkan untuk mempermudah admin mengelola banyak data sekaligus. Ini menghemat waktu dan meningkatkan efisiensi pengelolaan produk dan akun.

---

## 🎯 Fitur-Fitur Bulk

### 1. **Bulk Add Accounts** ➕👥
Tambah banyak akun sekaligus ke produk atau variasi.

#### Format Yang Didukung:

**a) Single JSON:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "desc": "Akun slot 1"
}
```

**b) Bulk JSON:**
```json
[
  {
    "email": "user1@example.com",
    "password": "pass123",
    "desc": "Slot 1"
  },
  {
    "email": "user2@example.com",
    "password": "pass456",
    "desc": "Slot 2"
  },
  {
    "email": "user3@example.com",
    "password": "pass789",
    "desc": "Slot 3"
  }
]
```

**c) CSV Format:**
```csv
email,password,desc
user1@example.com,pass123,Slot 1
user2@example.com,pass456,Slot 2
user3@example.com,pass789,Slot 3
```

#### Response:
```
✅ Bulk Add Selesai!

📦 Total: 10
✅ Berhasil: 8
❌ Gagal: 2

Produk: Netflix Premium
Stok baru: 45
```

---

### 2. **Bulk Add Variations** ➕📋
Tambah banyak variasi sekaligus ke produk.

#### Format Single:
```json
{
  "name": "30D 1pcs",
  "price": 5000
}
```

#### Format Bulk:
```json
[
  {
    "name": "7D 1pcs",
    "price": 1500
  },
  {
    "name": "30D 1pcs",
    "price": 5000
  },
  {
    "name": "60D 1pcs",
    "price": 9000
  },
  {
    "name": "90D 1pcs",
    "price": 12000
  }
]
```

#### Response:
```
✅ Bulk Add Variasi Selesai!

📦 Total: 4
✅ Berhasil: 4
❌ Gagal: 0

Produk: Canva Pro
Total Variasi: 4
```

---

### 3. **Bulk Update Prices** 💰
Update harga banyak produk sekaligus.

#### Cara Akses:
Admin Panel → **💰 Bulk Harga**

#### Format:
```json
[
  {
    "code": "NETFLIX_PRIVATE",
    "price": 120000
  },
  {
    "code": "DISNEY_PLUS",
    "price": 35000
  },
  {
    "code": "CANVA",
    "price": 600
  }
]
```

#### Response:
```
💰 BULK UPDATE HARGA SELESAI

📊 Statistik:
📦 Total: 3
✅ Berhasil: 3
❌ Tidak ditemukan: 0
⚠️ Gagal: 0

📋 Detail:
✅ Netflix Private 5 Profil: Rp100.000 → Rp120.000
✅ Disney+ Hotstar: Rp30.000 → Rp35.000
✅ Canv Pro: Rp500 → Rp600
```

---

### 4. **Bulk Update Descriptions** 📝
Update deskripsi banyak produk sekaligus.

#### Cara Akses:
Admin Panel → **📝 Bulk Desk**

#### Format:
```json
[
  {
    "code": "NETFLIX_PRIVATE",
    "desc": "Garansi 1 bulan, Private 5 profil"
  },
  {
    "code": "DISNEY_PLUS",
    "desc": "Garansi 30 hari, Hotstar Premium"
  },
  {
    "code": "CANVA",
    "desc": "Pro lifetime, full fitur"
  }
]
```

#### Response:
```
📝 BULK UPDATE DESKRIPSI SELESAI

📊 Statistik:
📦 Total: 3
✅ Berhasil: 3
❌ Tidak ditemukan: 0
⚠️ Gagal: 0

📋 Detail:
✅ Netflix Private 5 Profil: Deskripsi diperbarui
✅ Disney+ Hotstar: Deskripsi diperbarui
✅ Canv Pro: Deskripsi diperbarui
```

---

## 📋 Cara Menggunakan

### Step-by-Step Bulk Add Accounts:

1. **Akses Admin Panel**
   ```
   /admin
   ```

2. **Kelola Produk**
   - Klik "📦 Kelola Produk"
   - Pilih nomor produk
   - Klik "➕ Tambah Akun"

3. **Pilih Format**
   - **JSON Single**: Untuk 1 akun
   - **JSON Array**: Untuk banyak akun
   - **CSV**: Untuk import dari spreadsheet

4. **Kirim Data**
   - Copy-paste format yang dipilih
   - Bot akan memproses otomatis
   - Menerima konfirmasi dengan statistik

---

## 💡 Tips & Best Practices

### 1. **CSV Format**
- ✅ Header wajib: `email,password,desc`
- ✅ Tidak ada spasi sebelum/sesudah koma
- ✅ Satu baris per akun
- ❌ Jangan gunakan koma dalam deskripsi

### 2. **JSON Format**
- ✅ Gunakan JSON validator sebelum kirim
- ✅ Quote untuk string values
- ✅ Bracket `[]` untuk array
- ❌ Jangan ada trailing comma

### 3. **Bulk Price Update**
- ✅ Gunakan `code` produk (bukan nama)
- ✅ Harga dalam angka (tanpa Rp atau titik)
- ✅ Cek code produk di menu Kelola Produk
- ❌ Code harus UPPERCASE atau akan dikonversi otomatis

### 4. **Performance**
- 📌 Max 50 items per bulk operation (recommended)
- 📌 Untuk data besar, bagi menjadi beberapa batch
- 📌 Monitor response time dan stok

---

## 🔧 Technical Details

### CSV Parser
```javascript
function parseCSV(csvText) {
  const lines = csvText.trim().split('\n');
  const header = lines[0].split(',').map(h => h.trim().toLowerCase());
  const emailIdx = header.indexOf('email');
  const passwordIdx = header.indexOf('password');
  const descIdx = header.indexOf('desc');
  
  // Validation & parsing...
}
```

**Features:**
- Auto-detects CSV format (starts with "email,")
- Flexible header order
- Trims whitespace
- Validates required fields

### Bulk Operations Flow
```
User Input → Format Detection → Validation → Processing → Statistics → Save
```

1. **Format Detection**: CSV vs JSON
2. **Validation**: Check required fields
3. **Processing**: Loop through items
4. **Statistics**: Count success/failed
5. **Save**: Write to products.json

---

## 📊 Statistics & Reporting

Setiap bulk operation memberikan laporan detail:

```
✅ Bulk Add Selesai!

📦 Total: 100        → Total items processed
✅ Berhasil: 95      → Successfully added
❌ Gagal: 5          → Failed (invalid data)

Produk: Netflix Premium
Stok baru: 145
```

---

## 🎨 UI/UX Improvements

### Admin Menu Baru:
```
👑 ADMIN PANEL

📊 Statistik:
• Total Produk: 15
• Transaksi Pending: 3

[📦 Kelola Produk]
[➕ Tambah Produk]
[💰 Bulk Harga] [📝 Bulk Desk]
[📋 Lihat Transaksi]
[⚙️ Pengaturan]
[🔄 Refresh]
```

### Bulk Buttons:
- **💰 Bulk Harga** - Batch price updates
- **📝 Bulk Desk** - Batch description updates

---

## 🔐 Security & Validation

### Input Validation:
- ✅ JSON syntax check
- ✅ CSV format validation
- ✅ Required field validation
- ✅ Product code existence check
- ✅ Admin-only access

### Error Handling:
```javascript
try {
  data = JSON.parse(inputText);
} catch (e) {
  return ctx.reply('❌ Format tidak valid. Gunakan JSON atau CSV.');
}
```

---

## 📝 Examples

### Example 1: Bulk Add 50 Netflix Accounts (CSV)
```csv
email,password,desc
netflix1@example.com,pass123,Premium Slot 1
netflix2@example.com,pass456,Premium Slot 2
netflix3@example.com,pass789,Premium Slot 3
...
netflix50@example.com,pass999,Premium Slot 50
```

### Example 2: Bulk Update All Product Prices
```json
[
  {"code": "NETFLIX_PRIVATE", "price": 120000},
  {"code": "DISNEY_PLUS", "price": 35000},
  {"code": "CANVA", "price": 600},
  {"code": "SPOTIFY", "price": 15000},
  {"code": "YOUTUBE", "price": 25000}
]
```

### Example 3: Bulk Add Variations to Multiple Products
```json
[
  {"name": "7D 1pcs", "price": 1500},
  {"name": "14D 1pcs", "price": 2500},
  {"name": "30D 1pcs", "price": 5000},
  {"name": "60D 1pcs", "price": 9000},
  {"name": "90D 1pcs", "price": 12000}
]
```

---

## 🚀 Performance Metrics

### Before Bulk Features:
- ⏱️ Add 50 accounts: ~10 minutes (manual, one by one)
- ⏱️ Update 10 prices: ~5 minutes

### After Bulk Features:
- ⚡ Add 50 accounts: ~30 seconds (CSV import)
- ⚡ Update 10 prices: ~15 seconds (bulk JSON)

**Efficiency Gain: ~20x faster!**

---

## 🛠️ Troubleshooting

### Common Errors:

**Error: "Format tidak valid"**
- **Cause**: Invalid JSON or CSV syntax
- **Fix**: Use JSON validator or check CSV format

**Error: "Tidak ditemukan"**
- **Cause**: Product code doesn't exist
- **Fix**: Check product code in Kelola Produk

**Error: "Data tidak lengkap"**
- **Cause**: Missing email or password
- **Fix**: Ensure all required fields are present

---

## 📚 References

- **Admin Command**: `/admin`
- **Main Menu**: `/menu`
- **Help**: `/start`

### Related Files:
- `src/_bot.js` - Main bot logic with bulk handlers
- `src/products.json` - Product database
- `QRIS_INTERFACE_FEATURES.md` - QRIS payment features

---

## 🎯 Future Enhancements

Potential future features:
- [ ] Bulk delete accounts
- [ ] Bulk export (JSON/CSV)
- [ ] Import from external URL
- [ ] Scheduled bulk operations
- [ ] Bulk operations history log
- [ ] Excel (.xlsx) file support
- [ ] Bulk image upload for products

---

**Created**: October 2025  
**Version**: 1.0  
**Bot**: VORAKSSTORE BOT / PREMIUMISME

---

**Happy bulk managing! 🎉**

