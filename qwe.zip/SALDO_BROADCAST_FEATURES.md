# 💰 Saldo & Broadcast System Documentation

## Overview
This bot now includes a complete **Saldo (Balance) System** and **Broadcast Feature** for administrators.

---

## 🎯 Features Implemented

### 1. **User Balance System**
- ✅ Users can check their balance anytime
- ✅ Users can pay with balance (no additional fees!)
- ✅ Transaction history tracking
- ✅ Automatic balance deduction on purchase
- ✅ Balance notifications

### 2. **Admin Balance Management**
- ✅ Add balance to any user
- ✅ Reduce balance from any user
- ✅ Set balance to specific amount
- ✅ Check user balance and transaction history
- ✅ View all users with balance

### 3. **Broadcast System**
- ✅ Send messages to all registered users
- ✅ Supports Markdown formatting
- ✅ Success/failure statistics
- ✅ Rate limiting protection

---

## 📱 User Commands & Features

### Check Balance
Users can check their balance in three ways:

1. **Button**: Tap "💰 Cek Saldo" button from main menu
2. **Command**: Send `/saldo` command
3. **On Start**: Balance shown when user starts the bot with `/start`

**Display includes:**
- Current balance
- Last 5 transactions
- Transaction types (Add ➕, Reduce ➖, Set 🔄)

### Pay with Saldo
When ordering a product:

1. Select product and quantity
2. On order confirmation, you'll see two payment options:
   - 💳 BAYAR DENGAN QRIS
   - 💰 BAYAR DENGAN SALDO (if balance is sufficient)
3. If balance is insufficient, button shows current balance
4. Confirm payment with saldo
5. Receive products instantly (no waiting!)

**Benefits of Saldo Payment:**
- ⚡ Instant delivery
- 💸 No additional fees (vs QRIS with 0.7% + Rp200 fee)
- 🔒 Secure and tracked

---

## 👑 Admin Commands & Features

### Access Admin Panel
Send `/admin` command to access the admin panel.

### Balance Management

#### 1. Add Balance to User
**Path:** Admin Panel → 💵 Kelola Saldo → ➕ Add Saldo

**Format 1 (Simple):**
```
chatId amount note
```
**Example:**
```
123456789 50000 Bonus deposit
```

**Format 2 (JSON):**
```json
{
  "chatId": 123456789,
  "amount": 50000,
  "note": "Bonus deposit"
}
```

- User receives notification automatically
- Balance is added immediately

#### 2. Reduce Balance from User
**Path:** Admin Panel → 💵 Kelola Saldo → ➖ Reduce Saldo

**Format 1 (Simple):**
```
chatId amount note
```
**Example:**
```
123456789 30000 Koreksi saldo
```

**Format 2 (JSON):**
```json
{
  "chatId": 123456789,
  "amount": 30000,
  "note": "Koreksi saldo"
}
```

- Checks if user has sufficient balance
- User receives notification automatically

#### 3. Set Balance
**Path:** Admin Panel → 💵 Kelola Saldo → 🔄 Set Saldo

**Format 1 (Simple):**
```
chatId amount note
```
**Example:**
```
123456789 100000 Set saldo awal
```

**Format 2 (JSON):**
```json
{
  "chatId": 123456789,
  "amount": 100000,
  "note": "Set saldo awal"
}
```

- Overwrites current balance
- Useful for corrections or initial setup

#### 4. Check User Balance
**Path:** Admin Panel → 💵 Kelola Saldo → 🔍 Cek Saldo

**Check specific user:**
```
123456789
```

**Check all users with balance:**
```
ALL
```

**Response includes:**
- User details (name, username, chat ID)
- Current balance
- Last 10 transactions (if checking specific user)
- Sorted by balance (if checking all)

---

## 📢 Broadcast Feature

### How to Broadcast
**Path:** Admin Panel → 📢 Broadcast

1. Click "📢 Broadcast" button
2. Send your message (supports Markdown)
3. Bot will send to all registered users
4. You'll receive statistics: Success/Failed/Total

### Broadcast Statistics
After broadcast completes, you'll see:
- ✅ Successful deliveries
- ❌ Failed deliveries (blocked users, deleted accounts)
- 📊 Total users

### Markdown Formatting Examples

**Bold text:**
```
*This is bold*
```

**Italic text:**
```
_This is italic_
```

**Code:**
```
`This is code`
```

**Combined:**
```
🎉 *Special Promo!*

Get _50% OFF_ on all Netflix accounts!

Use code: `PROMO50`

Valid until: *December 31, 2024*
```

---

## 🗄️ Data Storage

### users.json
New file created at `src/users.json` stores:
- User information (chatId, username, name)
- Current balance
- Transaction history
- Registration date
- Last active time

**Automatic features:**
- Creates automatically when first user starts bot
- Updates on each user interaction
- Persists across bot restarts

---

## 💡 Tips & Best Practices

### For Admins:

1. **Finding User Chat ID:**
   - Ask user to send any message
   - Check bot console/logs for chat ID
   - Or use Telegram's get updates API

2. **Managing Balances:**
   - Use "Add" for bonuses/deposits
   - Use "Reduce" for corrections (checks balance first)
   - Use "Set" for complete resets/corrections

3. **Broadcasting:**
   - Test with your own account first
   - Use Markdown for better formatting
   - Keep messages concise and clear
   - Avoid too frequent broadcasts (spam protection)

4. **Monitoring:**
   - Check "ALL" balances regularly
   - Review transaction histories
   - Monitor broadcast success rates

### For Users:

1. **Balance Safety:**
   - Contact admin for top-ups
   - Check balance before ordering
   - Review transaction history regularly

2. **Payment Method:**
   - Use Saldo for instant delivery + no fees
   - Use QRIS if balance is insufficient

---

## 🔧 Technical Details

### User Manager Module
Location: `src/userManager.js`

**Functions:**
- `getUser(chatId, userInfo)` - Get/create user
- `getBalance(chatId)` - Get user balance
- `addBalance(chatId, amount, note)` - Add balance
- `reduceBalance(chatId, amount, note)` - Reduce balance
- `setBalance(chatId, amount, note)` - Set balance
- `getAllUsers()` - Get all users
- `getUserCount()` - Get total user count
- `getTransactions(chatId, limit)` - Get user transactions

### Payment Flow (Saldo)

1. User selects product + quantity
2. System checks:
   - Stock availability
   - User balance sufficiency
3. User confirms payment
4. System re-checks stock (prevent race conditions)
5. Balance deducted with transaction record
6. Accounts marked as used
7. Products delivered instantly
8. Transaction saved in user history

### Broadcast Flow

1. Admin sends message
2. System fetches all users from database
3. Iterates through each user
4. Sends message with 50ms delay (rate limiting)
5. Tracks success/failure
6. Returns statistics

---

## 🆘 Troubleshooting

### User can't see balance button
- Ask user to send `/start` command again
- Bot will update keyboard with balance button

### Balance not updating
- Check `src/users.json` file exists and is writable
- Check console for errors
- Restart bot if necessary

### Broadcast not working
- Verify you're an admin (check `.env` ADMIN_IDS)
- Check internet connection
- Users who blocked bot won't receive messages

### Payment with saldo fails
- Verify user has sufficient balance
- Check product stock availability
- Ensure `users.json` is writable

---

## 📊 Example Admin Workflow

### Daily Operations:

1. **Morning:**
   - Check `/admin` panel statistics
   - Review pending transactions
   - Check user balances (`ALL`)

2. **Customer Requests:**
   - Receive top-up request
   - Confirm payment received
   - Use "Add Saldo" to add balance
   - User receives instant notification

3. **Promotions:**
   - Create promotional message
   - Use Broadcast feature
   - Monitor success rate

4. **End of Day:**
   - Review all transactions
   - Check broadcast statistics
   - Monitor user growth

---

## 🎉 Success!

Your bot now has a complete balance and broadcast system! Users can enjoy instant purchases with saldo, and you can manage everything easily from the admin panel.

**Need help?** Check the main code in:
- `src/_bot.js` - Main bot logic
- `src/userManager.js` - User & balance management
- `src/users.json` - User data storage (created automatically)


