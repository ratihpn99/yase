# 🛠️ VPS Bug Fixes - Bot Stability Improvements

## 📋 Permasalahan yang Diperbaiki

Bot mengalami crash/error ketika dijalankan di VPS sehingga tidak bisa running 24 jam. Error terjadi pada bagian message formatting, terutama pada konfirmasi pembayaran SALDO dan QRIS.

## ✅ Solusi yang Diterapkan

### 1. **Fix Fungsi escapeMarkdown (CRITICAL FIX)**

**Masalah:**
- Bot menggunakan `parse_mode: 'Markdown'` (v1) di semua message
- Tapi fungsi `escapeMarkdown()` melakukan escape untuk MarkdownV2
- Ini menyebabkan karakter seperti `-`, `+`, `=`, `.`, `!` di-escape padahal tidak perlu
- Hasilnya: message error/crash karena format tidak sesuai

**Solusi:**
```javascript
// SEBELUM (SALAH - untuk MarkdownV2):
function escapeMarkdown(s = '') {
  return String(s)
    .replace(/\\/g, '\\\\')
    .replace(/\*/g, '\\*')
    .replace(/_/g, '\\_')
    .replace(/\[/g, '\\[')
    .replace(/\]/g, '\\]')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)')
    .replace(/~/g, '\\~')
    .replace(/`/g, '\\`')
    .replace(/>/g, '\\>')
    .replace(/#/g, '\\#')
    .replace(/\+/g, '\\+')
    .replace(/-/g, '\\-')  // ❌ TIDAK PERLU di Markdown v1
    .replace(/=/g, '\\=')  // ❌ TIDAK PERLU di Markdown v1
    .replace(/\|/g, '\\|')
    .replace(/\{/g, '\\{')
    .replace(/\}/g, '\\}')
    .replace(/\./g, '\\.')  // ❌ TIDAK PERLU di Markdown v1
    .replace(/!/g, '\\!');  // ❌ TIDAK PERLU di Markdown v1
}

// SESUDAH (BENAR - untuk Markdown v1):
function escapeMarkdown(s = '') {
  return String(s)
    .replace(/\\/g, '\\\\')
    .replace(/\*/g, '\\*')
    .replace(/_/g, '\\_')
    .replace(/`/g, '\\`')
    .replace(/\[/g, '\\[');
}
```

**Impact:** Ini adalah fix utama yang menyelesaikan error formatting pada message CANVA dan produk lainnya.

---

### 2. **Fix Escape Description Field**

**Masalah:**
- Field `desc` (deskripsi akun) tidak di-escape
- Jika desc mengandung karakter Markdown seperti `*`, `_`, `[`, bisa break message format

**Solusi:**
```javascript
// SEBELUM:
`📝 Deskripsi: ${a.desc || '-'}`

// SESUDAH:
`📝 Deskripsi: ${escapeMarkdown(a.desc || '-')}`
```

**Lokasi:**
- Konfirmasi pembayaran SALDO (line ~2998)
- Konfirmasi pembayaran QRIS (line ~3484)

---

### 3. **Global Error Handlers (CRITICAL untuk VPS)**

**Masalah:**
- Tidak ada error handler global
- Unhandled promise rejection atau uncaught exception akan crash bot
- Di VPS, ini membuat bot berhenti dan tidak restart otomatis

**Solusi:**
```javascript
// Prevent bot crashes from unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('⚠️ Unhandled Promise Rejection:', reason);
  console.error('Promise:', promise);
  // Don't exit, keep bot running
});

// Prevent bot crashes from uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('⚠️ Uncaught Exception:', error);
  // Don't exit, keep bot running
});

// Bot-level error handler
bot.catch((err, ctx) => {
  console.error('⚠️ Bot Error:', err);
  try {
    if (ctx && ctx.reply) {
      ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi atau hubungi admin.').catch(console.error);
    }
  } catch (e) {
    console.error('Error sending error message:', e);
  }
});
```

**Impact:** Bot tetap running meskipun ada error, tidak crash/stop.

---

### 4. **Try-Catch pada Message Sending**

**Masalah:**
- `ctx.editMessageText()` dan `ctx.reply()` bisa error
- Misalnya: message too old, user blocked bot, etc.
- Error ini bisa crash bot

**Solusi:**
Tambahkan try-catch dengan fallback:

```javascript
// Untuk SALDO payment confirmation:
try {
  await ctx.editMessageText(text, { 
    parse_mode: 'Markdown',
    disable_web_page_preview: true 
  });
} catch (err) {
  console.error('Error sending SALDO payment confirmation:', err.message);
  // Fallback: try to send as new message
  try {
    await ctx.reply(text, { 
      parse_mode: 'Markdown',
      disable_web_page_preview: true 
    });
  } catch (err2) {
    console.error('Error sending fallback message:', err2.message);
  }
}

// Untuk QRIS payment confirmation:
try {
  await bot.telegram.sendMessage(chatId, text, { 
    parse_mode: 'Markdown',
    disable_web_page_preview: true 
  });
} catch (err) {
  console.error('Error sending QRIS payment confirmation:', err.message);
}
```

---

### 5. **Error Handling pada saveProducts()**

**Masalah:**
- `saveProducts()` bisa error saat write file
- Misalnya: disk full, permission denied, etc.
- Error ini bisa crash bot

**Solusi:**
```javascript
function saveProducts() {
  try {
    products.forEach((p) => {
      // ... update stock logic ...
    });
    fs.writeFileSync(productsPath, JSON.stringify(products, null, 2), 'utf8');
  } catch (err) {
    console.error('❌ Error saving products:', err.message);
    // Don't throw, just log - prevents bot crash
  }
}
```

---

### 6. **Improved Bot Launch & Heartbeat**

**File: `src/index.js`**

**Masalah:**
- Launch code terlalu simple, tidak ada logging
- Sulit debug jika ada masalah
- Tidak ada indikator bot masih running

**Solusi:**
```javascript
bot.launch()
  .then(() => {
    console.log('✅ Bot started successfully!');
    console.log('⏰ Time:', new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }));
    console.log('🤖 Bot is now running 24/7...');
    
    // Heartbeat log every hour
    setInterval(() => {
      console.log('💓 Bot heartbeat:', new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }));
    }, 60 * 60 * 1000); // Every 1 hour
  })
  .catch((err) => {
    console.error('❌ Failed to start bot:', err);
    process.exit(1);
  });

// Graceful shutdown handlers
process.once('SIGINT', () => {
  console.log('⚠️ SIGINT received, stopping bot...');
  bot.stop('SIGINT');
});

process.once('SIGTERM', () => {
  console.log('⚠️ SIGTERM received, stopping bot...');
  bot.stop('SIGTERM');
});
```

**Benefits:**
- Logging jelas saat bot start
- Heartbeat tiap 1 jam untuk monitor bot masih hidup
- Graceful shutdown saat stop bot

---

## 📊 Ringkasan Perubahan

| File | Perubahan | Impact |
|------|-----------|--------|
| `src/_bot.js` | Fix escapeMarkdown() | **CRITICAL** - Fix message formatting error |
| `src/_bot.js` | Escape desc field | **HIGH** - Prevent message break dari desc |
| `src/_bot.js` | Global error handlers | **CRITICAL** - Prevent bot crash di VPS |
| `src/_bot.js` | Try-catch message sending | **HIGH** - Prevent crash dari message error |
| `src/_bot.js` | Try-catch saveProducts() | **MEDIUM** - Prevent crash dari file write error |
| `src/index.js` | Improved launch + heartbeat | **MEDIUM** - Better monitoring & logging |

---

## 🚀 Cara Deploy di VPS

### 1. Update Code
```bash
cd /path/to/bot
git pull  # atau upload file manual
```

### 2. Install Dependencies (jika perlu)
```bash
npm install
```

### 3. Test Run (foreground)
```bash
node src/index.js
```

Pastikan muncul:
```
✅ Bot started successfully!
⏰ Time: [waktu]
🤖 Bot is now running 24/7...
```

### 4. Run with PM2 (recommended untuk VPS)
```bash
# Install PM2 jika belum
npm install -g pm2

# Start bot with PM2
pm2 start src/index.js --name "telegram-bot"

# Auto restart on reboot
pm2 startup
pm2 save

# Monitor logs
pm2 logs telegram-bot

# Monitor status
pm2 status
```

### 5. Run with Screen (alternative)
```bash
# Start screen session
screen -S telegram-bot

# Run bot
node src/index.js

# Detach: Ctrl+A then D

# Reattach: 
screen -r telegram-bot
```

---

## 🔍 Monitoring & Debugging

### Check Bot Status
```bash
# With PM2:
pm2 status
pm2 logs telegram-bot --lines 100

# With Screen:
screen -r telegram-bot
```

### Look for Heartbeat
Bot akan log heartbeat tiap 1 jam:
```
💓 Bot heartbeat: 28/10/2025 14:00:00
```

Jika tidak ada heartbeat > 2 jam, ada masalah.

### Check Errors
Semua error akan di-log dengan prefix:
- `⚠️ Unhandled Promise Rejection:`
- `⚠️ Uncaught Exception:`
- `⚠️ Bot Error:`
- `❌ Error saving products:`
- `Error sending SALDO payment confirmation:`
- `Error sending QRIS payment confirmation:`

---

## ✅ Testing Checklist

Sebelum deploy ke production, test:

- [ ] Bot bisa start tanpa error
- [ ] Command /start bekerja
- [ ] Bisa browse produk
- [ ] Pembayaran SALDO berhasil (test dengan produk murah)
- [ ] Pembayaran QRIS berhasil
- [ ] Message formatting correct (tidak ada `\-` atau `\\` yang tampil)
- [ ] Bot tidak crash saat user cancel payment
- [ ] Bot tidak crash saat user block/unblock
- [ ] Heartbeat log muncul setiap jam

---

## 🆘 Troubleshooting

### Bot Still Crashes
1. Check PM2 logs: `pm2 logs telegram-bot`
2. Look for error patterns
3. Bisa share error log untuk analisa lebih lanjut

### Message Formatting Still Wrong
1. Pastikan semua produk di `products.json` tidak punya karakter aneh di field `name`
2. Check field `desc` di accounts, pastikan tidak ada karakter markdown kompleks
3. Kalau perlu, bersihkan manual di `products.json`

### Bot Running but Not Responding
1. Check Telegram API: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getMe`
2. Check VPS internet connection
3. Restart bot: `pm2 restart telegram-bot`

---

## 📝 Notes

- Semua error sekarang di-log, tidak langsung crash bot
- Bot akan tetap running meskipun ada error di individual message
- Heartbeat membantu monitoring bot masih hidup
- File operations (saveProducts, etc) sudah ada error handling
- Message sending sudah ada fallback mechanism

**Hasil Akhir:** Bot sekarang production-ready untuk running 24/7 di VPS! 🎉

