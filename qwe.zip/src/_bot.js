// === Dependencies ===
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const QRCode = require('qrcode');
const { Telegraf, Markup } = require('telegraf');

const atlantic = require('./atlanticClient');
const { BOT_TOKEN, ADMIN_IDS } = require('./config');
const userManager = require('./userManager');

if (!BOT_TOKEN) throw new Error('BOT_TOKEN belum diisi di .env');

// === Konfigurasi Fee & TTL ===
const FEE_PERCENT = 0.007;            // 0,7%
const FEE_FIXED   = 200;              // Rp200
const PAYMENT_TTL_MS = 5 * 60 * 1000; // 5 menit

// === Utils ===
function escapeHtml(s = '') {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Escape for Telegram Markdown v1 (NOT v2)
// Only escape: * _ ` [
function escapeMarkdown(s = '') {
  return String(s)
    .replace(/\\/g, '\\\\')
    .replace(/\*/g, '\\*')
    .replace(/_/g, '\\_')
    .replace(/`/g, '\\`')
    .replace(/\[/g, '\\[');
}

// CSV Parser for accounts
function parseCSV(csvText) {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) return [];
  
  const header = lines[0].split(',').map(h => h.trim().toLowerCase());
  const emailIdx = header.indexOf('email');
  const passwordIdx = header.indexOf('password');
  const descIdx = header.indexOf('desc');
  
  if (emailIdx === -1 || passwordIdx === -1) {
    throw new Error('CSV harus memiliki kolom "email" dan "password"');
  }
  
  const accounts = [];
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim());
    if (values.length < 2) continue;
    
    accounts.push({
      email: values[emailIdx] || '',
      password: values[passwordIdx] || '',
      desc: descIdx !== -1 ? (values[descIdx] || '') : ''
    });
  }
  
  return accounts;
}

function isAdmin(id) {
  if (!Array.isArray(ADMIN_IDS)) return false;
  return ADMIN_IDS.map(String).includes(String(id));
}

function idr(n) {
  try { return Number(n).toLocaleString('id-ID'); }
  catch { return String(n); }
}

// "17 Oktober 2025 pukul 17.57"
function fmtWIB(d = new Date()) {
  const tz = 'Asia/Jakarta';
  const day = new Intl.DateTimeFormat('id-ID', { day: '2-digit', timeZone: tz }).format(d);
  const month = new Intl.DateTimeFormat('id-ID', { month: 'long', timeZone: tz }).format(d);
  const year = new Intl.DateTimeFormat('id-ID', { year: 'numeric', timeZone: tz }).format(d);
  const hour = new Intl.DateTimeFormat('id-ID', { hour: '2-digit', hour12: false, timeZone: tz }).format(d);
  const minute = new Intl.DateTimeFormat('id-ID', { minute: '2-digit', timeZone: tz }).format(d);
  return `${day} ${month} ${year} pukul ${hour}.${minute}`;
}

// === Helpers kirim foto aman ===
// src: Buffer | {source:Buffer} | filePath | http(s) URL | long string (QR content)
async function ctxSendPhotoSafe(ctx, src, caption = '') {
  let buffer = null;

  try {
    if (Buffer.isBuffer(src)) {
      buffer = src;
    } else if (src && typeof src === 'object' && Buffer.isBuffer(src.source)) {
      buffer = src.source;
    } else if (typeof src === 'string') {
      if (!/^https?:\/\//i.test(src) && fs.existsSync(src)) {
        buffer = fs.readFileSync(src);
      } else if (/^https?:\/\//i.test(src)) {
        const res = await axios.get(src, { responseType: 'arraybuffer', timeout: 15000 });
        buffer = Buffer.from(res.data);
      } else if (src.length > 50) { // anggap QR string
        buffer = await QRCode.toBuffer(src, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
      }
    }
  } catch {
    if (!buffer && typeof src === 'string') {
      buffer = await QRCode.toBuffer(src, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  }

  if (!buffer) throw new Error('ctxSendPhotoSafe: unable to build buffer from src');

  const opts = caption ? { caption: escapeHtml(caption), parse_mode: 'HTML' } : {};
  try {
    return await ctx.replyWithPhoto({ source: buffer }, opts);
  } catch (err) {
    if (typeof src === 'string' && /^https?:\/\//i.test(src)) {
      return await ctx.replyWithPhoto(src, opts);
    }
    throw err;
  }
}

async function sendQrisPhoto(ctx, { qris_image, qris_string, caption = '' }) {
  let buf = null;

  try {
    if (qris_image && /^https?:\/\//i.test(qris_image)) {
      const res = await axios.get(qris_image, { responseType: 'arraybuffer', timeout: 15000 });
      buf = Buffer.from(res.data);
    } else if (qris_string) {
      buf = await QRCode.toBuffer(qris_string, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  } catch {
    if (qris_string) {
      buf = await QRCode.toBuffer(qris_string, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  }

  if (!buf) throw new Error('sendQrisPhoto: No QR source available');
  const opts = caption ? { caption: escapeHtml(caption), parse_mode: 'HTML' } : {};
  return ctx.replyWithPhoto({ source: buf }, opts);
}

// kirim QR + caption singkat
async function sendQrisImage(ctx, { qris_string, qris_image, invoice_id, ref, total_charge }) {
  await ctx.replyWithChatAction('upload_photo');
  // Just send QR without caption - caption will be sent separately
  if (qris_string) {
    const png = await QRCode.toBuffer(qris_string, { 
      scale: 10, 
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });
    return ctx.replyWithPhoto({ source: png });
  }
  if (qris_image) {
    try {
      const res = await axios.get(qris_image, { responseType: 'arraybuffer', timeout: 15000 });
      const buf = Buffer.from(res.data);
      return ctx.replyWithPhoto({ source: buf });
    } catch {
      return ctx.replyWithPhoto(qris_image);
    }
  }
  return null;
}

// === Data Produk ===
const productsPath = path.join(__dirname, 'products.json');
let products = [];
try {
  products = JSON.parse(fs.readFileSync(productsPath, 'utf8'));
} catch {
  products = [];
}
function saveProducts() {
  try {
    products.forEach((p) => {
      // Update stock for main accounts
      p.accounts = p.accounts || [];
      p.stock = p.accounts.filter((a) => !a.used).length;
      
      // Update stock for variations
      if (p.variations && Array.isArray(p.variations)) {
        p.variations.forEach((v) => {
          v.accounts = v.accounts || [];
          v.stock = v.accounts.filter((a) => !a.used).length;
        });
      }
    });
    fs.writeFileSync(productsPath, JSON.stringify(products, null, 2), 'utf8');
  } catch (err) {
    console.error('❌ Error saving products:', err.message);
    // Don't throw, just log - prevents bot crash
  }
}

// === Bot State ===
const bot = new Telegraf(BOT_TOKEN);
const session = new Map(); // chatId -> {}
/**
 * pending:
 *   invoice_id -> {
 *     chatId, ref, reff_id, code, qty,
 *     baseTotal, serviceFee, totalCharge,
 *     note, createdAt, expiresAt, productName
 *   }
 */
const pending = new Map();

/**
 * topupRequests:
 *   requestId -> {
 *     chatId, username, firstName, amount,
 *     paymentProof, note, status, createdAt, processedAt
 *   }
 */
const topupRequests = new Map();

/**
 * topupQris:
 *   invoice_id -> {
 *     chatId, amount, msgIds, createdAt, expiresAt
 *   }
 */
const topupQris = new Map();

// Track message IDs per invoice for auto-delete
function trackInvoiceMsg(invoice_id, msg) {
  try {
    if (!invoice_id || !msg || !msg.message_id) return;
    const rec = pending.get(invoice_id);
    if (!rec) return;
    rec.msgIds = rec.msgIds || new Set();
    rec.msgIds.add(msg.message_id);
  } catch {}
}
async function deleteInvoiceMessages(chatId, invoice_id) {
  try {
    const rec = pending.get(invoice_id);
    if (!rec || !rec.msgIds) return;
    for (const mid of rec.msgIds) {
      try { await bot.telegram.deleteMessage(chatId, mid); } catch {}
    }
    rec.msgIds.clear?.();
  } catch {}
}


function S(chatId) {
  if (!session.has(chatId)) session.set(chatId, {});
  return session.get(chatId);
}

// Safe answer callback query (ignore timeout errors)
async function safeAnswerCbQuery(ctx, text) {
  try {
    await ctx.answerCbQuery(text);
  } catch (e) {
    // Ignore "query is too old" errors
    if (!e.message?.includes('query is too old')) {
      console.error('answerCbQuery error:', e.message);
    }
  }
}

// === Keyboard Buttons (Bottom) ===
const mainKeyboard = Markup.keyboard([
  ['📦 List Produk', '💰 Cek Saldo'],
  ['💵 Top Up Saldo', '📜 Riwayat Transaksi'],
  ['✨ Produk Populer', '❓ Cara Order']
]).resize();

// === Start & Menu ===
bot.start((ctx) => {
  // Register user
  const user = userManager.getUser(ctx.chat.id, ctx.from);
  
  const text = `👋 *Selamat Datang!*\n\nSilakan pilih menu dari tombol di bawah atau klik /menu\n\n💰 *Saldo Anda:* Rp${idr(user.balance || 0)}`;
  ctx.reply(text, { parse_mode: 'Markdown', ...mainKeyboard });
});

bot.command('menu', (ctx) => {
  const text = '🏠 *MENU UTAMA*\n\nSilakan pilih menu dari tombol di bawah:';
  ctx.reply(text, { parse_mode: 'Markdown', ...mainKeyboard });
});

function showMainMenu(ctx) {
  const menuText = '🏠 *MENU UTAMA*\n\nSilakan pilih menu dari tombol di bawah:';
  
  if (ctx.callbackQuery) {
    ctx.editMessageText(menuText, { parse_mode: 'Markdown' });
  } else {
    ctx.reply(menuText, { parse_mode: 'Markdown', ...mainKeyboard });
  }
}

// === Handle text button commands ===
bot.hears('📦 List Produk', async (ctx) => {
  if (products.length === 0) return ctx.reply('Belum ada produk.');
  const st = S(ctx.chat.id);
  st.currentPage = 1;
  const { text, keyboard } = generateProductList(1);
  ctx.reply(text, keyboard);
});

bot.hears('📜 Riwayat Transaksi', async (ctx) => {
  const chatId = ctx.chat.id;
  
  // Get user's transaction history from pending/completed
  const userTransactions = [];
  for (const [invoice_id, payload] of pending.entries()) {
    if (payload.chatId === chatId) {
      userTransactions.push({
        invoice: invoice_id,
        ref: payload.ref,
        product: payload.productName,
        amount: payload.totalCharge,
        status: 'PENDING',
        date: new Date(payload.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
      });
    }
  }
  
  let text = '📜 *RIWAYAT TRANSAKSI*\n\n';
  if (userTransactions.length === 0) {
    text += 'Belum ada transaksi.';
  } else {
    userTransactions.forEach((trx, i) => {
      text += `${i + 1}. ${trx.product}\n`;
      text += `   Invoice: ${trx.invoice}\n`;
      text += `   Ref: ${trx.ref}\n`;
      text += `   Total: Rp${idr(trx.amount)}\n`;
      text += `   Status: ${trx.status}\n`;
      text += `   Tanggal: ${trx.date}\n\n`;
    });
  }
  
  ctx.reply(text, { parse_mode: 'Markdown' });
});

bot.hears('✨ Produk Populer', async (ctx) => {
  // Get top 10 products sorted by (total_accounts - available_accounts)
  const sortedProducts = [...products]
    .map(p => ({
      ...p,
      sold: p.accounts ? p.accounts.filter(a => a.used).length : 0
    }))
    .sort((a, b) => b.sold - a.sold)
    .slice(0, 10);
  
  let text = '✨ *PRODUK POPULER*\n\n';
  if (sortedProducts.length === 0) {
    text += 'Belum ada data produk.';
  } else {
    sortedProducts.forEach((p, i) => {
      text += `${i + 1}. ${p.name}\n`;
      text += `   Harga: Rp${idr(p.price)}\n`;
      text += `   Stok: ${p.stock || 0}\n`;
      text += `   Terjual: ${p.sold}\n\n`;
    });
  }
  
  ctx.reply(text, { parse_mode: 'Markdown' });
});

bot.hears('❓ Cara Order', async (ctx) => {
  const text = `❓ *CARA ORDER*

📝 Langkah-langkah pemesanan:

1️⃣ Klik "📦 List Produk" untuk melihat produk yang tersedia

2️⃣ Pilih produk yang ingin dibeli dengan mengklik nomor produk

3️⃣ Pilih jumlah akun yang ingin dibeli (1-5)

4️⃣ Konfirmasi pembelian dan klik "💳 Bayar Sekarang"

5️⃣ Scan QR Code yang muncul dengan aplikasi e-wallet Anda

6️⃣ Setelah pembayaran berhasil, akun akan otomatis dikirim ke chat ini

⏰ Waktu pembayaran: *5 menit*
💳 Metode pembayaran: *QRIS* (semua e-wallet) atau *Saldo*

📌 Note: Pastikan membayar sesuai nominal yang tertera!`;
  
  ctx.reply(text, { parse_mode: 'Markdown' });
});

bot.hears('💰 Cek Saldo', async (ctx) => {
  // Register/update user
  const user = userManager.getUser(ctx.chat.id, ctx.from);
  
  let text = `💰 *SALDO ANDA*\n\n`;
  text += `┌───────────────────────┐\n`;
  text += `│ Saldo Tersedia:\n`;
  text += `│ *Rp${idr(user.balance || 0)}*\n`;
  text += `└───────────────────────┘\n\n`;
  
  // Get recent transactions
  const transactions = userManager.getTransactions(ctx.chat.id, 5);
  
  if (transactions.length > 0) {
    text += `📜 *Riwayat Transaksi Terakhir:*\n\n`;
    transactions.forEach((t, i) => {
      const icon = t.type === 'ADD' ? '➕' : (t.type === 'REDUCE' ? '➖' : '🔄');
      const date = new Date(t.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      text += `${i + 1}. ${icon} Rp${idr(t.amount)}\n`;
      text += `   ${t.note}\n`;
      text += `   Saldo: Rp${idr(t.balanceAfter)}\n`;
      text += `   ${date}\n\n`;
    });
  } else {
    text += `📜 *Belum ada transaksi*\n\n`;
  }
  
  text += `💡 *Tips:* Hubungi admin untuk top up saldo!`;
  
  ctx.reply(text, { parse_mode: 'Markdown' });
});

// Command version
bot.command('saldo', async (ctx) => {
  const user = userManager.getUser(ctx.chat.id, ctx.from);
  
  let text = `💰 *SALDO ANDA*\n\n`;
  text += `┌───────────────────────┐\n`;
  text += `│ Saldo Tersedia:\n`;
  text += `│ *Rp${idr(user.balance || 0)}*\n`;
  text += `└───────────────────────┘\n\n`;
  
  const transactions = userManager.getTransactions(ctx.chat.id, 5);
  
  if (transactions.length > 0) {
    text += `📜 *Riwayat Transaksi Terakhir:*\n\n`;
    transactions.forEach((t, i) => {
      const icon = t.type === 'ADD' ? '➕' : (t.type === 'REDUCE' ? '➖' : '🔄');
      const date = new Date(t.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      text += `${i + 1}. ${icon} Rp${idr(t.amount)}\n`;
      text += `   ${t.note}\n`;
      text += `   Saldo: Rp${idr(t.balanceAfter)}\n`;
      text += `   ${date}\n\n`;
    });
  } else {
    text += `📜 *Belum ada transaksi*\n\n`;
  }
  
  text += `💡 *Tips:* Klik "💵 Top Up Saldo" untuk mengisi saldo!`;
  
  ctx.reply(text, { parse_mode: 'Markdown' });
});

// Top Up Saldo Menu
bot.hears('💵 Top Up Saldo', async (ctx) => {
  const user = userManager.getUser(ctx.chat.id, ctx.from);
  
  const text = `💵 *TOP UP SALDO*\n\n` +
    `Saldo Anda saat ini: *Rp${idr(user.balance || 0)}*\n\n` +
    `Pilih metode top up:\n\n` +
    `🤝 *Via Admin*\n` +
    `• Kirim permintaan ke admin\n` +
    `• Transfer manual ke rekening\n` +
    `• Konfirmasi ke admin\n` +
    `• Proses: 1-10 menit\n\n` +
    `⚡ *Via QRIS (Otomatis)*\n` +
    `• Bayar via QRIS\n` +
    `• Saldo masuk otomatis\n` +
    `• Proses: Instant!\n` +
    `• Fee: 0.7% + Rp200`;
  
  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🤝 Via Admin', 'TOPUP_MANUAL')],
    [Markup.button.callback('⚡ Via QRIS (Otomatis)', 'TOPUP_QRIS')],
    [Markup.button.callback('❓ Cara Top Up', 'TOPUP_INFO')]
  ]);
  
  ctx.reply(text, { parse_mode: 'Markdown', ...kb });
});

// Top Up Info
bot.action('TOPUP_INFO', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  
  const text = `❓ *CARA TOP UP SALDO*\n\n` +
    `*📌 METODE 1: Via Admin*\n` +
    `1️⃣ Klik "🤝 Via Admin"\n` +
    `2️⃣ Masukkan jumlah top up\n` +
    `3️⃣ Sistem akan kirim permintaan ke admin\n` +
    `4️⃣ Admin akan memberikan rekening\n` +
    `5️⃣ Transfer sesuai jumlah\n` +
    `6️⃣ Upload bukti transfer\n` +
    `7️⃣ Admin approve → Saldo masuk!\n\n` +
    `*⚡ METODE 2: Via QRIS*\n` +
    `1️⃣ Klik "⚡ Via QRIS"\n` +
    `2️⃣ Masukkan jumlah top up\n` +
    `3️⃣ Scan QR Code yang muncul\n` +
    `4️⃣ Bayar dari e-wallet apapun\n` +
    `5️⃣ Saldo masuk otomatis!\n\n` +
    `*💰 Biaya:*\n` +
    `• Via Admin: GRATIS\n` +
    `• Via QRIS: 0.7% + Rp200\n\n` +
    `*⏱️ Kecepatan:*\n` +
    `• Via Admin: 1-10 menit\n` +
    `• Via QRIS: INSTANT!`;
  
  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Kembali', 'TOPUP_MENU')]
  ]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('TOPUP_MENU', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const user = userManager.getUser(ctx.chat.id, ctx.from);
  
  const text = `💵 *TOP UP SALDO*\n\n` +
    `Saldo Anda saat ini: *Rp${idr(user.balance || 0)}*\n\n` +
    `Pilih metode top up:\n\n` +
    `🤝 *Via Admin*\n` +
    `• Kirim permintaan ke admin\n` +
    `• Transfer manual ke rekening\n` +
    `• Konfirmasi ke admin\n` +
    `• Proses: 1-10 menit\n\n` +
    `⚡ *Via QRIS (Otomatis)*\n` +
    `• Bayar via QRIS\n` +
    `• Saldo masuk otomatis\n` +
    `• Proses: Instant!\n` +
    `• Fee: 0.7% + Rp200`;
  
  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('🤝 Via Admin', 'TOPUP_MANUAL')],
    [Markup.button.callback('⚡ Via QRIS (Otomatis)', 'TOPUP_QRIS')],
    [Markup.button.callback('❓ Cara Top Up', 'TOPUP_INFO')]
  ]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// === Manual Top Up (Via Admin) ===
bot.action('TOPUP_MANUAL', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.topupAction = 'MANUAL_AMOUNT';
  
  const text = `🤝 *TOP UP VIA ADMIN*\n\n` +
    `Masukkan jumlah saldo yang ingin di top up:\n\n` +
    `Contoh: \`50000\` atau \`100000\`\n\n` +
    `*Minimum:* Rp10.000\n` +
    `*Biaya:* GRATIS (Tidak ada fee)\n\n` +
    `💡 Setelah mengirim jumlah, admin akan memberikan nomor rekening untuk transfer.`;
  
  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'TOPUP_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// === QRIS Top Up (Otomatis) ===
bot.action('TOPUP_QRIS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.topupAction = 'QRIS_AMOUNT';
  
  const text = `⚡ *TOP UP VIA QRIS*\n\n` +
    `Masukkan jumlah saldo yang ingin di top up:\n\n` +
    `Contoh: \`50000\` atau \`100000\`\n\n` +
    `*Minimum:* Rp10.000\n` +
    `*Biaya:* 0.7% + Rp200\n\n` +
    `💡 Anda akan mendapatkan QR Code untuk pembayaran.\n` +
    `Saldo akan masuk otomatis setelah pembayaran!`;
  
  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'TOPUP_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// === Menu Actions (for inline buttons) ===
bot.action('MAIN_MENU', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  showMainMenu(ctx);
});

// === /admin menu ===
bot.command('admin', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('⛔ Akses ditolak. Hanya untuk admin.');
  showAdminMenu(ctx);
});

function showAdminMenu(ctx) {
  const userCount = userManager.getUserCount();
  const pendingTopups = Array.from(topupRequests.values()).filter(r => r.status === 'pending').length;
  
  const text = `👑 *ADMIN PANEL*

Selamat datang di panel admin!
Gunakan tombol di bawah untuk mengelola sistem.

📊 *Statistik:*
• Total Produk: ${products.length}
• Transaksi Pending: ${pending.size}
• Top Up Requests: ${pendingTopups}
• Total User: ${userCount}`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📦 Kelola Produk', 'ADMIN_PRODUCTS')],
    [Markup.button.callback('➕ Tambah Produk', 'ADMIN_ADD_PRODUCT')],
    [
      Markup.button.callback('💰 Bulk Harga', 'ADMIN_BULK_PRICE'),
      Markup.button.callback('📝 Bulk Desk', 'ADMIN_BULK_DESC')
    ],
    [Markup.button.callback('📋 Lihat Transaksi', 'ADMIN_TRANSACTIONS')],
    [
      Markup.button.callback('💵 Kelola Saldo', 'ADMIN_SALDO_MENU'),
      Markup.button.callback('💳 Top Up Requests', 'ADMIN_TOPUP_REQUESTS')
    ],
    [
      Markup.button.callback('📢 Broadcast', 'ADMIN_BROADCAST'),
      Markup.button.callback('⚙️ Pengaturan', 'ADMIN_SETTINGS')
    ],
    [Markup.button.callback('🔄 Refresh', 'ADMIN_REFRESH')]
  ]);

  if (ctx.callbackQuery) {
    ctx.editMessageText(text, { parse_mode: 'Markdown', ...keyboard });
  } else {
    ctx.reply(text, { parse_mode: 'Markdown', ...keyboard });
  }
}

// Admin menu handlers
bot.action('ADMIN_REFRESH', async (ctx) => {
  await safeAnswerCbQuery(ctx, 'Diperbarui!');
  showAdminMenu(ctx);
});

bot.action('ADMIN_PRODUCTS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  showProductManagement(ctx, 1);
});

bot.action('ADMIN_TRANSACTIONS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  
  let text = '📋 *TRANSAKSI PENDING*\n\n';
  if (pending.size === 0) {
    text += 'Tidak ada transaksi pending.';
  } else {
    let i = 1;
    for (const [invoice_id, payload] of pending.entries()) {
      text += `${i}. Invoice: ${invoice_id}\n`;
      text += `   Produk: ${payload.productName}\n`;
      text += `   Qty: ${payload.qty}\n`;
      text += `   Total: Rp${idr(payload.totalCharge)}\n`;
      text += `   User ID: ${payload.chatId}\n\n`;
      i++;
    }
  }
  
  const kb = Markup.inlineKeyboard([[Markup.button.callback('⬅️ Kembali', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('ADMIN_SETTINGS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  
  const text = `⚙️ *PENGATURAN SISTEM*

📊 *Konfigurasi Saat Ini:*
• Fee Persen: ${(FEE_PERCENT * 100).toFixed(1)}%
• Fee Tetap: Rp${idr(FEE_FIXED)}
• Payment TTL: ${PAYMENT_TTL_MS / 60000} menit
• Total Admin: ${ADMIN_IDS?.length || 0}

📌 *Untuk mengubah pengaturan:*
Silakan edit file .env atau config.js`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('⬅️ Kembali', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('ADMIN_MENU', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  showAdminMenu(ctx);
});

// === Admin Saldo Management ===
bot.action('ADMIN_SALDO_MENU', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  
  const text = `💵 *KELOLA SALDO USER*

Pilih aksi yang ingin dilakukan:

• *Add Saldo* - Tambah saldo user
• *Reduce Saldo* - Kurangi saldo user
• *Set Saldo* - Set saldo user ke nilai tertentu
• *Cek Saldo* - Lihat saldo user tertentu`;

  const kb = Markup.inlineKeyboard([
    [
      Markup.button.callback('➕ Add Saldo', 'ADMIN_SALDO_ADD'),
      Markup.button.callback('➖ Reduce Saldo', 'ADMIN_SALDO_REDUCE')
    ],
    [
      Markup.button.callback('🔄 Set Saldo', 'ADMIN_SALDO_SET'),
      Markup.button.callback('🔍 Cek Saldo', 'ADMIN_SALDO_CHECK')
    ],
    [Markup.button.callback('⬅️ Kembali', 'ADMIN_MENU')]
  ]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('ADMIN_SALDO_ADD', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'SALDO_ADD';
  
  const text = `➕ *TAMBAH SALDO USER*

Format: \`chatId amount note\`

Contoh:
\`123456789 50000 Bonus deposit\`

Atau format JSON:
\`\`\`json
{
  "chatId": 123456789,
  "amount": 50000,
  "note": "Bonus deposit"
}
\`\`\`

📌 *Catatan:*
• chatId adalah ID Telegram user
• amount dalam Rupiah
• note adalah keterangan transaksi`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_SALDO_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('ADMIN_SALDO_REDUCE', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'SALDO_REDUCE';
  
  const text = `➖ *KURANGI SALDO USER*

Format: \`chatId amount note\`

Contoh:
\`123456789 30000 Koreksi saldo\`

Atau format JSON:
\`\`\`json
{
  "chatId": 123456789,
  "amount": 30000,
  "note": "Koreksi saldo"
}
\`\`\`

📌 *Catatan:*
• chatId adalah ID Telegram user
• amount dalam Rupiah
• note adalah keterangan transaksi
• Saldo user harus mencukupi`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_SALDO_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('ADMIN_SALDO_SET', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'SALDO_SET';
  
  const text = `🔄 *SET SALDO USER*

Format: \`chatId amount note\`

Contoh:
\`123456789 100000 Set saldo awal\`

Atau format JSON:
\`\`\`json
{
  "chatId": 123456789,
  "amount": 100000,
  "note": "Set saldo awal"
}
\`\`\`

📌 *Catatan:*
• chatId adalah ID Telegram user
• amount adalah saldo baru (menimpa saldo lama)
• note adalah keterangan transaksi`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_SALDO_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('ADMIN_SALDO_CHECK', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'SALDO_CHECK';
  
  const text = `🔍 *CEK SALDO USER*

Kirim Chat ID user yang ingin dicek:

Contoh:
\`123456789\`

Atau kirim "ALL" untuk melihat semua user dengan saldo.`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_SALDO_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// === Admin Top Up Requests ===
bot.action('ADMIN_TOPUP_REQUESTS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  
  const requests = Array.from(topupRequests.values())
    .filter(r => r.status === 'pending')
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
  let text = `💳 *TOP UP REQUESTS*\n\n`;
  
  if (requests.length === 0) {
    text += `Tidak ada permintaan top up pending.`;
  } else {
    text += `Total: ${requests.length} permintaan\n\n`;
    requests.forEach((r, i) => {
      const date = new Date(r.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      text += `${i + 1}. *${r.firstName || 'User'}*\n`;
      text += `   ID: \`${r.chatId}\`\n`;
      text += `   Jumlah: Rp${idr(r.amount)}\n`;
      text += `   Waktu: ${date}\n`;
      if (r.username) text += `   @${r.username}\n`;
      text += `   Request ID: \`${r.requestId}\`\n\n`;
    });
    text += `\n💡 Klik request ID untuk approve/reject.`;
  }
  
  const buttons = [];
  requests.forEach((r, i) => {
    if (i < 10) { // Max 10 requests per page
      buttons.push([Markup.button.callback(`Request #${i + 1} - Rp${idr(r.amount)}`, `TOPUP_REQ_${r.requestId}`)]);
    }
  });
  buttons.push([Markup.button.callback('🔄 Refresh', 'ADMIN_TOPUP_REQUESTS')]);
  buttons.push([Markup.button.callback('⬅️ Kembali', 'ADMIN_MENU')]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/TOPUP_REQ_(.+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const requestId = ctx.match[1];
  const request = topupRequests.get(requestId);
  
  if (!request) {
    return ctx.reply('❌ Request tidak ditemukan.');
  }
  
  const date = new Date(request.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  
  let text = `💳 *DETAIL TOP UP REQUEST*\n\n`;
  text += `*User:* ${request.firstName || 'Unknown'} ${request.lastName || ''}\n`;
  text += `*Username:* ${request.username ? '@' + request.username : '-'}\n`;
  text += `*Chat ID:* \`${request.chatId}\`\n`;
  text += `*Jumlah:* Rp${idr(request.amount)}\n`;
  text += `*Status:* ${request.status}\n`;
  text += `*Waktu:* ${date}\n`;
  if (request.note) text += `*Catatan:* ${request.note}\n`;
  text += `\n*Rekening untuk transfer:*\nBRI: 1234567890\nBCA: 0987654321\n\n`;
  text += `Kirim rekening ini ke user dan tunggu bukti transfer.`;
  
  const kb = Markup.inlineKeyboard([
    [
      Markup.button.callback('✅ Approve', `TOPUP_APPROVE_${requestId}`),
      Markup.button.callback('❌ Reject', `TOPUP_REJECT_${requestId}`)
    ],
    [Markup.button.callback('📞 Contact User', `TOPUP_CONTACT_${requestId}`)],
    [Markup.button.callback('⬅️ Kembali', 'ADMIN_TOPUP_REQUESTS')]
  ]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action(/TOPUP_APPROVE_(.+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const requestId = ctx.match[1];
  const request = topupRequests.get(requestId);
  
  if (!request) {
    return ctx.reply('❌ Request tidak ditemukan.');
  }
  
  // Add balance to user
  const user = userManager.addBalance(request.chatId, request.amount, `Top up via admin - Request #${requestId}`);
  
  // Update request status
  request.status = 'approved';
  request.processedAt = new Date().toISOString();
  
  // Notify user
  try {
    await bot.telegram.sendMessage(
      request.chatId,
      `✅ *TOP UP BERHASIL!*\n\n` +
      `Saldo Anda telah ditambahkan:\n` +
      `Jumlah: Rp${idr(request.amount)}\n` +
      `Saldo baru: Rp${idr(user.balance)}\n\n` +
      `Terima kasih telah melakukan top up! 🎉`,
      { parse_mode: 'Markdown' }
    );
  } catch (e) {
    await ctx.reply(`⚠️ Saldo sudah ditambahkan, tapi gagal mengirim notifikasi ke user.`);
  }
  
  await ctx.reply(`✅ Request approved! Saldo Rp${idr(request.amount)} telah ditambahkan ke user ${request.chatId}.`);
  
  // Return to requests list
  const requests = Array.from(topupRequests.values())
    .filter(r => r.status === 'pending')
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
  let text = `💳 *TOP UP REQUESTS*\n\n`;
  
  if (requests.length === 0) {
    text += `Tidak ada permintaan top up pending.`;
  } else {
    text += `Total: ${requests.length} permintaan\n\n`;
    requests.forEach((r, i) => {
      const date = new Date(r.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      text += `${i + 1}. *${r.firstName || 'User'}*\n`;
      text += `   ID: \`${r.chatId}\`\n`;
      text += `   Jumlah: Rp${idr(r.amount)}\n`;
      text += `   Waktu: ${date}\n`;
      if (r.username) text += `   @${r.username}\n`;
      text += `   Request ID: \`${r.requestId}\`\n\n`;
    });
  }
  
  const buttons = [];
  requests.forEach((r, i) => {
    if (i < 10) {
      buttons.push([Markup.button.callback(`Request #${i + 1} - Rp${idr(r.amount)}`, `TOPUP_REQ_${r.requestId}`)]);
    }
  });
  buttons.push([Markup.button.callback('🔄 Refresh', 'ADMIN_TOPUP_REQUESTS')]);
  buttons.push([Markup.button.callback('⬅️ Kembali', 'ADMIN_MENU')]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/TOPUP_REJECT_(.+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const requestId = ctx.match[1];
  const request = topupRequests.get(requestId);
  
  if (!request) {
    return ctx.reply('❌ Request tidak ditemukan.');
  }
  
  // Update request status
  request.status = 'rejected';
  request.processedAt = new Date().toISOString();
  
  // Notify user
  try {
    await bot.telegram.sendMessage(
      request.chatId,
      `❌ *TOP UP DITOLAK*\n\n` +
      `Permintaan top up Anda sebesar Rp${idr(request.amount)} ditolak.\n\n` +
      `Silakan hubungi admin untuk informasi lebih lanjut.`,
      { parse_mode: 'Markdown' }
    );
  } catch (e) {
    await ctx.reply(`⚠️ Request ditolak, tapi gagal mengirim notifikasi ke user.`);
  }
  
  await ctx.reply(`❌ Request rejected untuk user ${request.chatId}.`);
  showAdminMenu(ctx);
});

bot.action(/TOPUP_CONTACT_(.+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const requestId = ctx.match[1];
  const request = topupRequests.get(requestId);
  
  if (!request) {
    return ctx.reply('❌ Request tidak ditemukan.');
  }
  
  const text = `📞 *CONTACT USER*\n\n` +
    `Untuk menghubungi user, gunakan:\n\n` +
    `*Method 1: Send Message*\n` +
    `Gunakan admin panel untuk broadcast atau send message langsung.\n\n` +
    `*Method 2: Telegram*\n` +
    `${request.username ? 'Username: @' + request.username : 'User tidak punya username'}\n` +
    `Chat ID: \`${request.chatId}\`\n\n` +
    `*Method 3: Bot Command*\n` +
    `Kirim rekening transfer:\n` +
    `\`\`\`\n` +
    `BRI: 1234567890 a.n. Nama Anda\n` +
    `BCA: 0987654321 a.n. Nama Anda\n` +
    `\`\`\``;
  
  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Kembali', `TOPUP_REQ_${requestId}`)]
  ]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// === Admin Broadcast ===
bot.action('ADMIN_BROADCAST', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'BROADCAST';
  
  const userCount = userManager.getUserCount();
  
  const text = `📢 *BROADCAST PESAN*

Kirim pesan yang ingin dikirim ke semua user.

📊 *Total User:* ${userCount}

⚠️ *Perhatian:*
• Pesan akan dikirim ke semua user yang pernah memulai bot
• Pesan dapat berupa teks, markdown, atau HTML
• Gunakan format Markdown untuk styling

💡 *Tips:*
• Gunakan *bold* untuk teks tebal
• Gunakan _italic_ untuk teks miring
• Gunakan \`code\` untuk kode

Kirim pesan broadcast sekarang:`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Bulk Price Update Handler
bot.action('ADMIN_BULK_PRICE', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'BULK_PRICE';
  
  const text = `💰 *BULK UPDATE HARGA*

Update harga banyak produk sekaligus!

📦 *Format JSON:*
\`\`\`json
[
  {
    "code": "NETFLIX_PRIVATE",
    "price": 120000
  },
  {
    "code": "DISNEY_PLUS",
    "price": 35000
  },
  {
    "code": "CANVA",
    "price": 600
  }
]
\`\`\`

📌 *Catatan:*
• Gunakan \`code\` produk yang sudah ada
• Harga baru akan menimpa harga lama
• Produk yang tidak ditemukan akan dilewati

💡 *Tips:* Lihat code produk di menu Kelola Produk`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Bulk Description Update Handler
bot.action('ADMIN_BULK_DESC', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'BULK_DESC';
  
  const text = `📝 *BULK UPDATE DESKRIPSI*

Update deskripsi banyak produk sekaligus!

📦 *Format JSON:*
\`\`\`json
[
  {
    "code": "NETFLIX_PRIVATE",
    "desc": "Garansi 1 bulan, Private 5 profil"
  },
  {
    "code": "DISNEY_PLUS",
    "desc": "Garansi 30 hari, Hotstar Premium"
  },
  {
    "code": "CANVA",
    "desc": "Pro lifetime, full fitur"
  }
]
\`\`\`

📌 *Catatan:*
• Gunakan \`code\` produk yang sudah ada
• Deskripsi baru akan menimpa deskripsi lama
• Produk yang tidak ditemukan akan dilewati

💡 *Tips:* Lihat code produk di menu Kelola Produk`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Product Management
const PRODUCTS_PER_ADMIN_PAGE = 10;

function showProductManagement(ctx, page = 1) {
  const totalPages = Math.ceil(products.length / PRODUCTS_PER_ADMIN_PAGE);
  const currentPage = Math.max(1, Math.min(page, totalPages));
  const startIdx = (currentPage - 1) * PRODUCTS_PER_ADMIN_PAGE;
  const endIdx = Math.min(startIdx + PRODUCTS_PER_ADMIN_PAGE, products.length);
  
  const pageProducts = products.slice(startIdx, endIdx);
  
  let text = `📦 *KELOLA PRODUK* (${currentPage}/${totalPages})\n\n`;
  
  pageProducts.forEach((p, i) => {
    const idx = startIdx + i;
    text += `${idx + 1}. *${escapeMarkdown(p.name)}*\n`;
    text += `   Code: ${escapeMarkdown(p.code)}\n`;
    text += `   Harga: Rp${idr(p.price)}\n`;
    text += `   Stok: ${p.stock || 0}\n`;
    if (p.variations) text += `   Variasi: ${p.variations.length}\n`;
    text += `\n`;
  });
  
  const buttons = [];
  const row = [];
  pageProducts.forEach((_, i) => {
    const idx = startIdx + i;
    row.push(Markup.button.callback(String(idx + 1), `ADMIN_EDIT_PROD_${idx}`));
    if (row.length === 5) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  
  // Navigation
  const navBtns = [];
  if (currentPage > 1) {
    navBtns.push(Markup.button.callback('⬅️ Prev', `ADMIN_PROD_PAGE_${currentPage - 1}`));
  }
  if (currentPage < totalPages) {
    navBtns.push(Markup.button.callback('Next ➡️', `ADMIN_PROD_PAGE_${currentPage + 1}`));
  }
  if (navBtns.length > 0) buttons.push(navBtns);
  
  buttons.push([Markup.button.callback('⬅️ Kembali ke Menu', 'ADMIN_MENU')]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
}

bot.action(/ADMIN_PROD_PAGE_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const page = Number(ctx.match[1]);
  showProductManagement(ctx, page);
});

// Edit Product Menu
bot.action(/ADMIN_EDIT_PROD_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminEditingProduct = idx;
  
  let text = `✏️ *EDIT PRODUK*\n\n`;
  text += `*Nama:* ${escapeMarkdown(p.name)}\n`;
  text += `*Code:* ${escapeMarkdown(p.code)}\n`;
  text += `*Harga:* Rp${idr(p.price)}\n`;
  text += `*Stok:* ${p.stock || 0}\n`;
  text += `*Deskripsi:* ${escapeMarkdown(p.desc || '-')}\n`;
  if (p.variations) {
    text += `\n*Variasi:* ${p.variations.length}\n`;
    p.variations.forEach((v, i) => {
      text += `  ${i + 1}. ${escapeMarkdown(v.name)} - Rp${idr(v.price)} (Stok: ${v.stock || 0})\n`;
    });
  }
  text += `\n*Total Akun:* ${p.accounts?.length || 0}`;
  
  const buttons = [
    [
      Markup.button.callback('💰 Ubah Harga', `ADMIN_CHANGE_PRICE_${idx}`),
      Markup.button.callback('📝 Ubah Desk', `ADMIN_CHANGE_DESC_${idx}`)
    ],
    [
      Markup.button.callback('➕ Tambah Variasi', `ADMIN_ADD_VAR_${idx}`),
      Markup.button.callback('✏️ Edit Variasi', `ADMIN_EDIT_VAR_${idx}`)
    ],
    [
      Markup.button.callback('👤 Kelola Akun', `ADMIN_MANAGE_ACC_${idx}`),
      Markup.button.callback('➕ Tambah Akun', `ADMIN_ADD_ACC_${idx}`)
    ],
    [Markup.button.callback('🗑️ Hapus Produk', `ADMIN_DEL_PROD_${idx}`)],
    [Markup.button.callback('⬅️ Kembali', 'ADMIN_PRODUCTS')]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Add Product Handler
bot.action('ADMIN_ADD_PRODUCT', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'ADD_PRODUCT';
  
  const text = `➕ *TAMBAH PRODUK BARU*

Kirim data produk dalam format JSON:

\`\`\`json
{
  "code": "PRODUCT_CODE",
  "name": "Nama Produk",
  "price": 10000,
  "desc": "Deskripsi produk"
}
\`\`\`

Contoh:
\`\`\`json
{
  "code": "SPOTIFY",
  "name": "Spotify Premium",
  "price": 15000,
  "desc": "Premium 1 bulan"
}
\`\`\``;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Delete Product Handler
bot.action(/ADMIN_DEL_PROD_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const text = `🗑️ *HAPUS PRODUK*

Yakin ingin menghapus produk ini?

*Nama:* ${escapeMarkdown(p.name)}
*Code:* ${escapeMarkdown(p.code)}
*Stok:* ${p.stock || 0}

⚠️ Tindakan ini tidak dapat dibatalkan!`;

  const buttons = [
    [
      Markup.button.callback('✅ Ya, Hapus', `ADMIN_CONFIRM_DEL_${idx}`),
      Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)
    ]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_CONFIRM_DEL_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const prodName = p.name;
  products.splice(idx, 1);
  saveProducts();
  
  await ctx.reply(`✅ Produk "${prodName}" berhasil dihapus!`);
  showProductManagement(ctx, 1);
});

// Change Price Handler
bot.action(/ADMIN_CHANGE_PRICE_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'CHANGE_PRICE';
  st.adminEditingProduct = idx;
  
  const text = `💰 *UBAH HARGA*

Produk: *${escapeMarkdown(p.name)}*
Harga saat ini: *Rp${idr(p.price)}*

Kirim harga baru (hanya angka):
Contoh: 15000`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Change Description Handler
bot.action(/ADMIN_CHANGE_DESC_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'CHANGE_DESC';
  st.adminEditingProduct = idx;
  
  const text = `📝 *UBAH DESKRIPSI*

Produk: *${escapeMarkdown(p.name)}*
Deskripsi saat ini: ${escapeMarkdown(p.desc || '-')}

Kirim deskripsi baru:`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Add Variation Handler (supports single or bulk)
bot.action(/ADMIN_ADD_VAR_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'ADD_VARIATION';
  st.adminEditingProduct = idx;
  
  const text = `➕ *TAMBAH VARIASI (Single / Bulk)*

Produk: *${escapeMarkdown(p.name)}*

📌 *Format SINGLE:*
\`\`\`json
{
  "name": "30D 1pcs",
  "price": 5000
}
\`\`\`

📦 *Format BULK (Multiple):*
\`\`\`json
[
  {
    "name": "7D 1pcs",
    "price": 1500
  },
  {
    "name": "30D 1pcs",
    "price": 5000
  },
  {
    "name": "60D 1pcs",
    "price": 9000
  }
]
\`\`\`

💡 *Tips:* Gunakan array \`[ ]\` untuk menambah banyak variasi sekaligus!`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Edit Variation Handler
bot.action(/ADMIN_EDIT_VAR_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p || !p.variations || p.variations.length === 0) {
    return ctx.reply('Produk tidak memiliki variasi.');
  }
  
  let text = `✏️ *EDIT VARIASI*\n\nProduk: *${escapeMarkdown(p.name)}*\n\nPilih variasi yang ingin diedit:\n\n`;
  p.variations.forEach((v, i) => {
    text += `${i + 1}. ${escapeMarkdown(v.name)} - Rp${idr(v.price)} (Stok: ${v.stock || 0})\n`;
  });
  
  const buttons = [];
  const row = [];
  p.variations.forEach((v, i) => {
    row.push(Markup.button.callback(String(i + 1), `ADMIN_SEL_VAR_${idx}_${i}`));
    if (row.length === 5) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  buttons.push([Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_SEL_VAR_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_SEL_VAR_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p.variations[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const text = `✏️ *EDIT VARIASI*

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*
Harga: Rp${idr(v.price)}
Stok: ${v.stock || 0}
Total Akun: ${v.accounts?.length || 0}

Pilih aksi:`;

  const buttons = [
    [
      Markup.button.callback('💰 Ubah Harga', `ADMIN_VAR_PRICE_${prodIdx}_${varIdx}`),
      Markup.button.callback('✏️ Ubah Nama', `ADMIN_VAR_NAME_${prodIdx}_${varIdx}`)
    ],
    [
      Markup.button.callback('➕ Tambah Akun', `ADMIN_VAR_ADD_ACC_${prodIdx}_${varIdx}`),
      Markup.button.callback('👤 Kelola Akun', `ADMIN_VAR_MANAGE_ACC_${prodIdx}_${varIdx}`)
    ],
    [Markup.button.callback('🗑️ Hapus Variasi', `ADMIN_VAR_DEL_${prodIdx}_${varIdx}`)],
    [Markup.button.callback('⬅️ Kembali', `ADMIN_EDIT_VAR_${prodIdx}`)]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Variation handlers
bot.action(/ADMIN_VAR_PRICE_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_PRICE_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'CHANGE_VAR_PRICE';
  st.adminEditingProduct = prodIdx;
  st.adminEditingVariation = varIdx;
  
  const text = `💰 *UBAH HARGA VARIASI*

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*
Harga saat ini: *Rp${idr(v.price)}*

Kirim harga baru (hanya angka):
Contoh: 15000`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action(/ADMIN_VAR_NAME_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_NAME_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'CHANGE_VAR_NAME';
  st.adminEditingProduct = prodIdx;
  st.adminEditingVariation = varIdx;
  
  const text = `✏️ *UBAH NAMA VARIASI*

Produk: *${escapeMarkdown(p.name)}*
Nama saat ini: *${escapeMarkdown(v.name)}*

Kirim nama baru:
Contoh: 30D 1pcs`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action(/ADMIN_VAR_ADD_ACC_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_ADD_ACC_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'ADD_VAR_ACCOUNT';
  st.adminEditingProduct = prodIdx;
  st.adminEditingVariation = varIdx;
  
  const text = `➕ *TAMBAH AKUN KE VARIASI (Single / Bulk / CSV)*

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*

📌 *Format SINGLE JSON:*
\`\`\`json
{
  "email": "user@example.com",
  "password": "password123",
  "desc": "Akun slot 1"
}
\`\`\`

📦 *Format BULK JSON:*
\`\`\`json
[
  {
    "email": "user1@example.com",
    "password": "pass123",
    "desc": "Slot 1"
  },
  {
    "email": "user2@example.com",
    "password": "pass456",
    "desc": "Slot 2"
  }
]
\`\`\`

📄 *Format CSV:*
\`\`\`
email,password,desc
user1@ex.com,pass123,Slot 1
user2@ex.com,pass456,Slot 2
\`\`\`

💡 *Tips:* JSON array atau CSV untuk bulk!`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action(/ADMIN_VAR_MANAGE_ACC_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_MANAGE_ACC_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  let text = `👤 *KELOLA AKUN VARIASI*\n\nProduk: *${escapeMarkdown(p.name)}*\nVariasi: *${escapeMarkdown(v.name)}*\n\n`;
  
  if (!v.accounts || v.accounts.length === 0) {
    text += 'Belum ada akun.';
  } else {
    v.accounts.forEach((a, i) => {
      text += `${i + 1}. ${a.email}\n`;
      text += `   Password: ${a.password}\n`;
      text += `   Status: ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
      text += `   Desc: ${a.desc || '-'}\n\n`;
    });
  }
  
  const buttons = [];
  if (v.accounts && v.accounts.length > 0) {
    buttons.push([Markup.button.callback('🗑️ Hapus Akun', `ADMIN_VAR_DEL_ACC_${prodIdx}_${varIdx}`)]);
  }
  buttons.push([Markup.button.callback('⬅️ Kembali', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_VAR_DEL_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_DEL_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const text = `🗑️ *HAPUS VARIASI*

Yakin ingin menghapus variasi ini?

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*
Harga: Rp${idr(v.price)}
Stok: ${v.stock || 0}

⚠️ Tindakan ini tidak dapat dibatalkan!`;

  const buttons = [
    [
      Markup.button.callback('✅ Ya, Hapus', `ADMIN_VAR_CONFIRM_DEL_${prodIdx}_${varIdx}`),
      Markup.button.callback('❌ Batal', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)
    ]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_VAR_CONFIRM_DEL_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_CONFIRM_DEL_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  
  if (!p || !p.variations || !p.variations[varIdx]) {
    return ctx.reply('Variasi tidak ditemukan.');
  }
  
  const varName = p.variations[varIdx].name;
  p.variations.splice(varIdx, 1);
  saveProducts();
  
  await ctx.reply(`✅ Variasi "${varName}" berhasil dihapus dari "${p.name}"!`);
  showAdminMenu(ctx);
});

bot.action(/ADMIN_VAR_DEL_ACC_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_DEL_ACC_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v || !v.accounts || v.accounts.length === 0) {
    return ctx.reply('Tidak ada akun untuk dihapus.');
  }
  
  let text = `🗑️ *HAPUS AKUN DARI VARIASI*\n\nProduk: *${escapeMarkdown(p.name)}*\nVariasi: *${escapeMarkdown(v.name)}*\n\nPilih akun yang ingin dihapus:\n\n`;
  
  v.accounts.forEach((a, i) => {
    text += `${i + 1}. ${a.email} - ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
  });
  
  const buttons = [];
  const row = [];
  v.accounts.forEach((a, i) => {
    row.push(Markup.button.callback(String(i + 1), `ADMIN_VAR_CONFIRM_DEL_ACC_${prodIdx}_${varIdx}_${i}`));
    if (row.length === 5) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  buttons.push([Markup.button.callback('❌ Batal', `ADMIN_VAR_MANAGE_ACC_${prodIdx}_${varIdx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_VAR_CONFIRM_DEL_ACC_(\d+)_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const match = ctx.match[0].match(/ADMIN_VAR_CONFIRM_DEL_ACC_(\d+)_(\d+)_(\d+)/);
  const [_, prodIdx, varIdx, accIdx] = match.map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v || !v.accounts || !v.accounts[accIdx]) {
    return ctx.reply('Akun tidak ditemukan.');
  }
  
  const accEmail = v.accounts[accIdx].email;
  v.accounts.splice(accIdx, 1);
  saveProducts();
  
  await ctx.reply(`✅ Akun "${accEmail}" berhasil dihapus dari variasi "${escapeMarkdown(v.name)}"!\nStok baru: ${v.stock}`);
  
  // Return to variation management
  const text = `✏️ *EDIT VARIASI*

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*
Harga: Rp${idr(v.price)}
Stok: ${v.stock || 0}
Total Akun: ${v.accounts?.length || 0}

Pilih aksi:`;

  const buttons = [
    [
      Markup.button.callback('💰 Ubah Harga', `ADMIN_VAR_PRICE_${prodIdx}_${varIdx}`),
      Markup.button.callback('✏️ Ubah Nama', `ADMIN_VAR_NAME_${prodIdx}_${varIdx}`)
    ],
    [
      Markup.button.callback('➕ Tambah Akun', `ADMIN_VAR_ADD_ACC_${prodIdx}_${varIdx}`),
      Markup.button.callback('👤 Kelola Akun', `ADMIN_VAR_MANAGE_ACC_${prodIdx}_${varIdx}`)
    ],
    [Markup.button.callback('🗑️ Hapus Variasi', `ADMIN_VAR_DEL_${prodIdx}_${varIdx}`)],
    [Markup.button.callback('⬅️ Kembali', `ADMIN_EDIT_VAR_${prodIdx}`)]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Manage Accounts Handler
bot.action(/ADMIN_MANAGE_ACC_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  let text = `👤 *KELOLA AKUN*\n\nProduk: *${escapeMarkdown(p.name)}*\n\n`;
  
  if (!p.accounts || p.accounts.length === 0) {
    text += 'Belum ada akun.';
  } else {
    p.accounts.forEach((a, i) => {
      text += `${i + 1}. ${a.email}\n`;
      text += `   Password: ${a.password}\n`;
      text += `   Status: ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
      text += `   Desc: ${a.desc || '-'}\n\n`;
    });
  }
  
  const buttons = [];
  if (p.accounts && p.accounts.length > 0) {
    buttons.push([Markup.button.callback('🗑️ Hapus Akun', `ADMIN_SELECT_DEL_ACC_${idx}`)]);
  }
  buttons.push([Markup.button.callback('⬅️ Kembali', `ADMIN_EDIT_PROD_${idx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Delete Account Selection Handler
bot.action(/ADMIN_SELECT_DEL_ACC_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p || !p.accounts || p.accounts.length === 0) {
    return ctx.reply('Tidak ada akun untuk dihapus.');
  }
  
  let text = `🗑️ *HAPUS AKUN*\n\nProduk: *${escapeMarkdown(p.name)}*\n\nPilih akun yang ingin dihapus:\n\n`;
  
  p.accounts.forEach((a, i) => {
    text += `${i + 1}. ${a.email} - ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
  });
  
  const buttons = [];
  const row = [];
  p.accounts.forEach((a, i) => {
    row.push(Markup.button.callback(String(i + 1), `ADMIN_CONFIRM_DEL_ACC_${idx}_${i}`));
    if (row.length === 5) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  buttons.push([Markup.button.callback('❌ Batal', `ADMIN_MANAGE_ACC_${idx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_CONFIRM_DEL_ACC_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, accIdx] = ctx.match[0].match(/ADMIN_CONFIRM_DEL_ACC_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  
  if (!p || !p.accounts || !p.accounts[accIdx]) {
    return ctx.reply('Akun tidak ditemukan.');
  }
  
  const accEmail = p.accounts[accIdx].email;
  p.accounts.splice(accIdx, 1);
  saveProducts();
  
  await ctx.reply(`✅ Akun "${accEmail}" berhasil dihapus dari "${escapeMarkdown(p.name)}"!\nStok baru: ${p.stock}`);
  
  // Return to manage accounts page
  let text = `👤 *KELOLA AKUN*\n\nProduk: *${escapeMarkdown(p.name)}*\n\n`;
  
  if (!p.accounts || p.accounts.length === 0) {
    text += 'Belum ada akun.';
  } else {
    p.accounts.forEach((a, i) => {
      text += `${i + 1}. ${a.email}\n`;
      text += `   Password: ${a.password}\n`;
      text += `   Status: ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
      text += `   Desc: ${a.desc || '-'}\n\n`;
    });
  }
  
  const buttons = [];
  if (p.accounts && p.accounts.length > 0) {
    buttons.push([Markup.button.callback('🗑️ Hapus Akun', `ADMIN_SELECT_DEL_ACC_${prodIdx}`)]);
  }
  buttons.push([Markup.button.callback('⬅️ Kembali', `ADMIN_EDIT_PROD_${prodIdx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Add Account Handler (supports single or bulk)
bot.action(/ADMIN_ADD_ACC_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'ADD_ACCOUNT';
  st.adminEditingProduct = idx;
  
  const text = `➕ *TAMBAH AKUN (Single / Bulk / CSV)*

Produk: *${escapeMarkdown(p.name)}*

📌 *Format SINGLE JSON:*
\`\`\`json
{
  "email": "user@example.com",
  "password": "password123",
  "desc": "Akun slot 1"
}
\`\`\`

📦 *Format BULK JSON:*
\`\`\`json
[
  {
    "email": "user1@example.com",
    "password": "pass123",
    "desc": "Slot 1"
  },
  {
    "email": "user2@example.com",
    "password": "pass456",
    "desc": "Slot 2"
  }
]
\`\`\`

📄 *Format CSV (baris per baris):*
\`\`\`
email,password,desc
user1@example.com,pass123,Slot 1
user2@example.com,pass456,Slot 2
user3@example.com,pass789,Slot 3
\`\`\`

💡 *Tips:* 
• JSON: Gunakan array \`[ ]\` untuk bulk
• CSV: Header wajib, lalu data per baris`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Handle text input for users (topup flow)
bot.on('text', async (ctx) => {
  const st = S(ctx.chat.id);
  
  // Handle user topup actions first
  if (st.topupAction) {
    const action = st.topupAction;
    
    try {
      if (action === 'MANUAL_AMOUNT' || action === 'QRIS_AMOUNT') {
        const amount = parseInt(ctx.message.text.replace(/[^0-9]/g, ''), 10);
        
        if (isNaN(amount) || amount < 10000) {
          return ctx.reply('❌ Jumlah tidak valid. Minimum Rp10.000.\nContoh: 50000');
        }
        
        if (action === 'MANUAL_AMOUNT') {
          // Create manual topup request
          const requestId = `REQ_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
          
          topupRequests.set(requestId, {
            requestId,
            chatId: ctx.chat.id,
            username: ctx.from.username,
            firstName: ctx.from.first_name,
            lastName: ctx.from.last_name,
            amount,
            status: 'pending',
            createdAt: new Date().toISOString()
          });
          
          st.topupAction = null;
          
          const text = `✅ *PERMINTAAN TOP UP DIKIRIM*\n\n` +
            `Jumlah: Rp${idr(amount)}\n` +
            `Request ID: \`${requestId}\`\n\n` +
            `Admin akan segera memproses permintaan Anda dan memberikan nomor rekening untuk transfer.\n\n` +
            `Setelah transfer, upload bukti transfer ke chat ini.\n\n` +
            `⏱️ Estimasi: 1-10 menit`;
          
          await ctx.reply(text, { parse_mode: 'Markdown' });
          
          // Notify all admins
          for (const adminId of ADMIN_IDS) {
            try {
              await bot.telegram.sendMessage(
                adminId,
                `🔔 *TOP UP REQUEST BARU*\n\n` +
                `User: ${ctx.from.first_name || 'Unknown'}\n` +
                `${ctx.from.username ? '@' + ctx.from.username : ''}\n` +
                `Chat ID: \`${ctx.chat.id}\`\n` +
                `Jumlah: Rp${idr(amount)}\n` +
                `Request ID: \`${requestId}\`\n\n` +
                `Gunakan /admin untuk memproses.`,
                { parse_mode: 'Markdown' }
              );
            } catch (e) {
              console.error('Failed to notify admin:', e);
            }
          }
          
          return;
        }
        
        if (action === 'QRIS_AMOUNT') {
          // Process QRIS topup
          st.topupAction = null;
          
          await processQrisTopup(ctx, amount);
          return;
        }
      }
    } catch (e) {
      ctx.reply(`❌ Error: ${e.message}`);
      st.topupAction = null;
      return;
    }
  }
  
  // Admin actions
  if (!isAdmin(ctx.from.id)) return;
  
  if (!st.adminAction) return;
  
  const action = st.adminAction;
  const prodIdx = st.adminEditingProduct;
  
  try {
    switch (action) {
      case 'ADD_PRODUCT': {
        const data = JSON.parse(ctx.message.text);
        if (!data.code || !data.name || !data.price) {
          return ctx.reply('❌ Data tidak lengkap. Harus ada code, name, dan price.');
        }
        data.code = String(data.code).toUpperCase();
        data.accounts = [];
        data.stock = 0;
        products.push(data);
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Produk "${data.name}" berhasil ditambahkan!`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'CHANGE_PRICE': {
        const price = parseInt(ctx.message.text, 10);
        if (isNaN(price) || price < 0) {
          return ctx.reply('❌ Harga harus berupa angka positif.');
        }
        const p = products[prodIdx];
        if (!p) return ctx.reply('Produk tidak ditemukan.');
        p.price = price;
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Harga "${p.name}" diubah menjadi Rp${idr(price)}`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'CHANGE_DESC': {
        const p = products[prodIdx];
        if (!p) return ctx.reply('Produk tidak ditemukan.');
        p.desc = ctx.message.text;
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Deskripsi "${p.name}" berhasil diubah!`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'ADD_VARIATION': {
        const data = JSON.parse(ctx.message.text);
        const p = products[prodIdx];
        if (!p) return ctx.reply('Produk tidak ditemukan.');
        p.variations = p.variations || [];
        
        // Check if bulk (array) or single (object)
        if (Array.isArray(data)) {
          // Bulk add variations
          let added = 0;
          let failed = 0;
          for (const variation of data) {
            if (!variation.name || !variation.price) {
              failed++;
              continue;
            }
            p.variations.push({
              name: variation.name,
              price: variation.price,
              accounts: [],
              stock: 0
            });
            added++;
          }
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ *Bulk Add Variasi Selesai!*\n\n📦 Total: ${data.length}\n✅ Berhasil: ${added}\n❌ Gagal: ${failed}\n\n*Produk:* ${p.name}\n*Total Variasi:* ${p.variations.length}`, { parse_mode: 'Markdown' });
        } else {
          // Single add variation
          if (!data.name || !data.price) {
            return ctx.reply('❌ Data tidak lengkap. Harus ada name dan price.');
          }
          p.variations.push({
            name: data.name,
            price: data.price,
            accounts: [],
            stock: 0
          });
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ Variasi "${data.name}" ditambahkan ke "${p.name}"!`);
        }
        showAdminMenu(ctx);
        break;
      }
      
      case 'ADD_ACCOUNT': {
        const p = products[prodIdx];
        if (!p) return ctx.reply('Produk tidak ditemukan.');
        p.accounts = p.accounts || [];
        
        let data;
        const inputText = ctx.message.text.trim();
        
        // Check if CSV format (starts with "email," header)
        if (inputText.toLowerCase().startsWith('email,')) {
          try {
            data = parseCSV(inputText);
          } catch (e) {
            return ctx.reply(`❌ Error parsing CSV: ${e.message}`);
          }
        } else {
          // Try JSON parse
          try {
            data = JSON.parse(inputText);
          } catch (e) {
            return ctx.reply('❌ Format tidak valid. Gunakan JSON atau CSV.\n\nContoh CSV:\nemail,password,desc\nuser@ex.com,pass123,Slot 1');
          }
        }
        
        // Check if bulk (array) or single (object)
        if (Array.isArray(data)) {
          // Bulk add accounts
          let added = 0;
          let failed = 0;
          for (const acc of data) {
            if (!acc.email || !acc.password) {
              failed++;
              continue;
            }
            p.accounts.push({
              email: acc.email,
              password: acc.password,
              desc: acc.desc || '',
              used: false
            });
            added++;
          }
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ *Bulk Add Selesai!*\n\n📦 Total: ${data.length}\n✅ Berhasil: ${added}\n❌ Gagal: ${failed}\n\n*Produk:* ${p.name}\n*Stok baru:* ${p.stock}`, { parse_mode: 'Markdown' });
        } else {
          // Single add account
          if (!data.email || !data.password) {
            return ctx.reply('❌ Data tidak lengkap. Harus ada email dan password.');
          }
          p.accounts.push({
            email: data.email,
            password: data.password,
            desc: data.desc || '',
            used: false
          });
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ Akun berhasil ditambahkan ke "${p.name}"!\nStok baru: ${p.stock}`);
        }
        showAdminMenu(ctx);
        break;
      }
      
      case 'CHANGE_VAR_PRICE': {
        const price = parseInt(ctx.message.text, 10);
        if (isNaN(price) || price < 0) {
          return ctx.reply('❌ Harga harus berupa angka positif.');
        }
        const p = products[prodIdx];
        const v = p?.variations?.[st.adminEditingVariation];
        if (!v) return ctx.reply('Variasi tidak ditemukan.');
        v.price = price;
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Harga variasi "${v.name}" diubah menjadi Rp${idr(price)}`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'CHANGE_VAR_NAME': {
        const p = products[prodIdx];
        const v = p?.variations?.[st.adminEditingVariation];
        if (!v) return ctx.reply('Variasi tidak ditemukan.');
        v.name = ctx.message.text;
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Nama variasi "${p.name}" berhasil diubah menjadi "${v.name}"!`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'BULK_PRICE': {
        const data = JSON.parse(ctx.message.text);
        if (!Array.isArray(data)) {
          return ctx.reply('❌ Format harus berupa array. Contoh: [{"code":"NETFLIX","price":120000}]');
        }
        
        let updated = 0;
        let notFound = 0;
        let failed = 0;
        const results = [];
        
        for (const item of data) {
          if (!item.code || !item.price) {
            failed++;
            continue;
          }
          
          const p = products.find(x => x.code === item.code.toUpperCase());
          if (!p) {
            notFound++;
            results.push(`❌ ${item.code}: Tidak ditemukan`);
            continue;
          }
          
          const oldPrice = p.price;
          p.price = item.price;
          updated++;
          results.push(`✅ ${p.name}: Rp${idr(oldPrice)} → Rp${idr(item.price)}`);
        }
        
        saveProducts();
        st.adminAction = null;
        
        let text = `💰 *BULK UPDATE HARGA SELESAI*\n\n📊 *Statistik:*\n`;
        text += `📦 Total: ${data.length}\n`;
        text += `✅ Berhasil: ${updated}\n`;
        text += `❌ Tidak ditemukan: ${notFound}\n`;
        text += `⚠️ Gagal: ${failed}\n\n`;
        text += `📋 *Detail:*\n${results.join('\n')}`;
        
        await ctx.reply(text, { parse_mode: 'Markdown' });
        showAdminMenu(ctx);
        break;
      }
      
      case 'BULK_DESC': {
        const data = JSON.parse(ctx.message.text);
        if (!Array.isArray(data)) {
          return ctx.reply('❌ Format harus berupa array. Contoh: [{"code":"NETFLIX","desc":"Garansi 1 bulan"}]');
        }
        
        let updated = 0;
        let notFound = 0;
        let failed = 0;
        const results = [];
        
        for (const item of data) {
          if (!item.code || !item.desc) {
            failed++;
            continue;
          }
          
          const p = products.find(x => x.code === item.code.toUpperCase());
          if (!p) {
            notFound++;
            results.push(`❌ ${item.code}: Tidak ditemukan`);
            continue;
          }
          
          p.desc = item.desc;
          updated++;
          results.push(`✅ ${p.name}: Deskripsi diperbarui`);
        }
        
        saveProducts();
        st.adminAction = null;
        
        let text = `📝 *BULK UPDATE DESKRIPSI SELESAI*\n\n📊 *Statistik:*\n`;
        text += `📦 Total: ${data.length}\n`;
        text += `✅ Berhasil: ${updated}\n`;
        text += `❌ Tidak ditemukan: ${notFound}\n`;
        text += `⚠️ Gagal: ${failed}\n\n`;
        text += `📋 *Detail:*\n${results.join('\n')}`;
        
        await ctx.reply(text, { parse_mode: 'Markdown' });
        showAdminMenu(ctx);
        break;
      }
      
      case 'ADD_VAR_ACCOUNT': {
        const p = products[prodIdx];
        const v = p?.variations?.[st.adminEditingVariation];
        if (!v) return ctx.reply('Variasi tidak ditemukan.');
        v.accounts = v.accounts || [];
        
        let data;
        const inputText = ctx.message.text.trim();
        
        // Check if CSV format (starts with "email," header)
        if (inputText.toLowerCase().startsWith('email,')) {
          try {
            data = parseCSV(inputText);
          } catch (e) {
            return ctx.reply(`❌ Error parsing CSV: ${e.message}`);
          }
        } else {
          // Try JSON parse
          try {
            data = JSON.parse(inputText);
          } catch (e) {
            return ctx.reply('❌ Format tidak valid. Gunakan JSON atau CSV.\n\nContoh CSV:\nemail,password,desc\nuser@ex.com,pass123,Slot 1');
          }
        }
        
        // Check if bulk (array) or single (object)
        if (Array.isArray(data)) {
          // Bulk add accounts
          let added = 0;
          let failed = 0;
          for (const acc of data) {
            if (!acc.email || !acc.password) {
              failed++;
              continue;
            }
            v.accounts.push({
              email: acc.email,
              password: acc.password,
              desc: acc.desc || '',
              used: false
            });
            added++;
          }
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ *Bulk Add Variasi Selesai!*\n\n📦 Total: ${data.length}\n✅ Berhasil: ${added}\n❌ Gagal: ${failed}\n\n*Produk:* ${p.name}\n*Variasi:* ${v.name}\n*Stok baru:* ${v.stock}`, { parse_mode: 'Markdown' });
        } else {
          // Single add account
          if (!data.email || !data.password) {
            return ctx.reply('❌ Data tidak lengkap. Harus ada email dan password.');
          }
          v.accounts.push({
            email: data.email,
            password: data.password,
            desc: data.desc || '',
            used: false
          });
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ Akun berhasil ditambahkan ke variasi "${v.name}"!\nStok baru: ${v.stock}`);
        }
        showAdminMenu(ctx);
        break;
      }
      
      case 'SALDO_ADD': {
        // Parse input - support both simple format and JSON
        let chatId, amount, note;
        const inputText = ctx.message.text.trim();
        
        try {
          // Try JSON format first
          const data = JSON.parse(inputText);
          chatId = data.chatId;
          amount = data.amount;
          note = data.note || 'Tambah saldo oleh admin';
        } catch {
          // Try simple format: chatId amount note
          const parts = inputText.split(' ');
          if (parts.length < 2) {
            return ctx.reply('❌ Format salah. Gunakan: chatId amount note\nContoh: 123456789 50000 Bonus deposit');
          }
          chatId = parseInt(parts[0], 10);
          amount = parseInt(parts[1], 10);
          note = parts.slice(2).join(' ') || 'Tambah saldo oleh admin';
        }
        
        if (isNaN(chatId) || isNaN(amount) || amount <= 0) {
          return ctx.reply('❌ Format salah. chatId dan amount harus berupa angka positif.');
        }
        
        const user = userManager.addBalance(chatId, amount, note);
        st.adminAction = null;
        
        await ctx.reply(`✅ *Saldo berhasil ditambahkan!*\n\n*User ID:* ${chatId}\n*Jumlah:* Rp${idr(amount)}\n*Saldo baru:* Rp${idr(user.balance)}\n*Catatan:* ${note}`, { parse_mode: 'Markdown' });
        
        // Notify user
        try {
          await bot.telegram.sendMessage(chatId, `💰 *SALDO DITAMBAHKAN*\n\nJumlah: Rp${idr(amount)}\nSaldo baru: Rp${idr(user.balance)}\n\nCatatan: ${note}`, { parse_mode: 'Markdown' });
        } catch (e) {
          await ctx.reply(`⚠️ Gagal mengirim notifikasi ke user: ${e.message}`);
        }
        
        showAdminMenu(ctx);
        break;
      }
      
      case 'SALDO_REDUCE': {
        let chatId, amount, note;
        const inputText = ctx.message.text.trim();
        
        try {
          const data = JSON.parse(inputText);
          chatId = data.chatId;
          amount = data.amount;
          note = data.note || 'Kurangi saldo oleh admin';
        } catch {
          const parts = inputText.split(' ');
          if (parts.length < 2) {
            return ctx.reply('❌ Format salah. Gunakan: chatId amount note\nContoh: 123456789 30000 Koreksi saldo');
          }
          chatId = parseInt(parts[0], 10);
          amount = parseInt(parts[1], 10);
          note = parts.slice(2).join(' ') || 'Kurangi saldo oleh admin';
        }
        
        if (isNaN(chatId) || isNaN(amount) || amount <= 0) {
          return ctx.reply('❌ Format salah. chatId dan amount harus berupa angka positif.');
        }
        
        const user = userManager.reduceBalance(chatId, amount, note);
        
        if (!user) {
          return ctx.reply(`❌ Saldo tidak cukup! User memiliki saldo: Rp${idr(userManager.getBalance(chatId))}`);
        }
        
        st.adminAction = null;
        
        await ctx.reply(`✅ *Saldo berhasil dikurangi!*\n\n*User ID:* ${chatId}\n*Jumlah:* Rp${idr(amount)}\n*Saldo baru:* Rp${idr(user.balance)}\n*Catatan:* ${note}`, { parse_mode: 'Markdown' });
        
        // Notify user
        try {
          await bot.telegram.sendMessage(chatId, `💰 *SALDO DIKURANGI*\n\nJumlah: Rp${idr(amount)}\nSaldo baru: Rp${idr(user.balance)}\n\nCatatan: ${note}`, { parse_mode: 'Markdown' });
        } catch (e) {
          await ctx.reply(`⚠️ Gagal mengirim notifikasi ke user: ${e.message}`);
        }
        
        showAdminMenu(ctx);
        break;
      }
      
      case 'SALDO_SET': {
        let chatId, amount, note;
        const inputText = ctx.message.text.trim();
        
        try {
          const data = JSON.parse(inputText);
          chatId = data.chatId;
          amount = data.amount;
          note = data.note || 'Set saldo oleh admin';
        } catch {
          const parts = inputText.split(' ');
          if (parts.length < 2) {
            return ctx.reply('❌ Format salah. Gunakan: chatId amount note\nContoh: 123456789 100000 Set saldo awal');
          }
          chatId = parseInt(parts[0], 10);
          amount = parseInt(parts[1], 10);
          note = parts.slice(2).join(' ') || 'Set saldo oleh admin';
        }
        
        if (isNaN(chatId) || isNaN(amount) || amount < 0) {
          return ctx.reply('❌ Format salah. chatId dan amount harus berupa angka.');
        }
        
        const user = userManager.setBalance(chatId, amount, note);
        st.adminAction = null;
        
        await ctx.reply(`✅ *Saldo berhasil di-set!*\n\n*User ID:* ${chatId}\n*Saldo baru:* Rp${idr(user.balance)}\n*Catatan:* ${note}`, { parse_mode: 'Markdown' });
        
        // Notify user
        try {
          await bot.telegram.sendMessage(chatId, `💰 *SALDO DIPERBARUI*\n\nSaldo baru: Rp${idr(user.balance)}\n\nCatatan: ${note}`, { parse_mode: 'Markdown' });
        } catch (e) {
          await ctx.reply(`⚠️ Gagal mengirim notifikasi ke user: ${e.message}`);
        }
        
        showAdminMenu(ctx);
        break;
      }
      
      case 'SALDO_CHECK': {
        const inputText = ctx.message.text.trim();
        
        if (inputText.toUpperCase() === 'ALL') {
          // Show all users with balance
          const allUsers = userManager.getAllUsers();
          const usersWithBalance = allUsers.filter(u => u.balance > 0);
          
          if (usersWithBalance.length === 0) {
            st.adminAction = null;
            return ctx.reply('📊 Tidak ada user dengan saldo.');
          }
          
          let text = `📊 *DAFTAR USER DENGAN SALDO*\n\nTotal: ${usersWithBalance.length}\n\n`;
          
          usersWithBalance
            .sort((a, b) => b.balance - a.balance)
            .forEach((u, i) => {
              text += `${i + 1}. *${u.firstName || 'User'}* ${u.lastName || ''}\n`;
              text += `   ID: \`${u.chatId}\`\n`;
              text += `   Saldo: Rp${idr(u.balance)}\n`;
              if (u.username) text += `   @${u.username}\n`;
              text += `\n`;
            });
          
          st.adminAction = null;
          await ctx.reply(text, { parse_mode: 'Markdown' });
          showAdminMenu(ctx);
        } else {
          // Check specific user
          const chatId = parseInt(inputText, 10);
          
          if (isNaN(chatId)) {
            return ctx.reply('❌ Format salah. Kirim Chat ID (angka) atau "ALL".');
          }
          
          const user = userManager.getUser(chatId);
          const transactions = userManager.getTransactions(chatId, 10);
          
          let text = `👤 *INFO USER*\n\n`;
          text += `*Nama:* ${user.firstName || '-'} ${user.lastName || ''}\n`;
          text += `*Username:* ${user.username ? '@' + user.username : '-'}\n`;
          text += `*Chat ID:* \`${user.chatId}\`\n`;
          text += `*Saldo:* Rp${idr(user.balance)}\n\n`;
          
          if (transactions.length > 0) {
            text += `📜 *Riwayat Transaksi (10 terakhir):*\n\n`;
            transactions.forEach((t, i) => {
              const icon = t.type === 'ADD' ? '➕' : (t.type === 'REDUCE' ? '➖' : '🔄');
              text += `${i + 1}. ${icon} Rp${idr(t.amount)} - ${t.note}\n`;
              text += `   Saldo: Rp${idr(t.balanceAfter)}\n`;
            });
          }
          
          st.adminAction = null;
          await ctx.reply(text, { parse_mode: 'Markdown' });
          showAdminMenu(ctx);
        }
        break;
      }
      
      case 'BROADCAST': {
        const message = ctx.message.text;
        const allUsers = userManager.getAllUsers();
        
        st.adminAction = null;
        
        await ctx.reply(`📢 *Memulai broadcast...*\n\nTotal user: ${allUsers.length}`, { parse_mode: 'Markdown' });
        
        let success = 0;
        let failed = 0;
        
        for (const user of allUsers) {
          try {
            await bot.telegram.sendMessage(user.chatId, message, { parse_mode: 'Markdown' });
            success++;
            // Add small delay to avoid rate limiting
            await new Promise(resolve => setTimeout(resolve, 50));
          } catch (e) {
            failed++;
          }
        }
        
        await ctx.reply(`✅ *Broadcast selesai!*\n\n✅ Berhasil: ${success}\n❌ Gagal: ${failed}\n📊 Total: ${allUsers.length}`, { parse_mode: 'Markdown' });
        showAdminMenu(ctx);
        break;
      }
    }
  } catch (e) {
    ctx.reply(`❌ Error: ${e.message}\nPastikan format JSON benar.`);
  }
});

// === List produk dengan pagination ===
const PRODUCTS_PER_PAGE = 15;

function generateProductList(page = 1) {
  const totalPages = Math.ceil(products.length / PRODUCTS_PER_PAGE);
  const currentPage = Math.max(1, Math.min(page, totalPages));
  const startIdx = (currentPage - 1) * PRODUCTS_PER_PAGE;
  const endIdx = Math.min(startIdx + PRODUCTS_PER_PAGE, products.length);
  
  const pageProducts = products.slice(startIdx, endIdx);
  const lines = pageProducts.map((p, i) => 
    `[${startIdx + i + 1}] ${p.name.toUpperCase()}`
  );
  
  const header = `┌─────────────────────┐
│     LIST PRODUK     │
│    page ${currentPage} / ${totalPages}    │
└─────────────────────┘`;
  
  const text = header + '\n\n' + lines.join('\n');
  
  // Create number buttons (5 per row)
  const btns = pageProducts.map((_, i) => 
    Markup.button.callback(String(startIdx + i + 1), `SEL_${startIdx + i}`)
  );
  const rows = [];
  for (let i = 0; i < btns.length; i += 5) {
    rows.push(btns.slice(i, i + 5));
  }
  
  // Add navigation buttons
  const navBtns = [];
  if (currentPage > 1) {
    navBtns.push(Markup.button.callback('Sebelumnya', `PAGE_${currentPage - 1}`));
  }
  if (currentPage < totalPages) {
    navBtns.push(Markup.button.callback('Berikutnya', `PAGE_${currentPage + 1}`));
  }
  if (navBtns.length > 0) rows.push(navBtns);
  
  return { text, keyboard: Markup.inlineKeyboard(rows) };
}

bot.action('LIST_PROD', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  if (products.length === 0) return ctx.editMessageText('Belum ada produk.');
  const st = S(ctx.chat.id);
  st.currentPage = 1;
  const { text, keyboard } = generateProductList(1);
  ctx.editMessageText(text, keyboard);
});

// Handle pagination
bot.action(/PAGE_\d+/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const page = Number(ctx.match[0].split('_')[1]);
  const st = S(ctx.chat.id);
  st.currentPage = page;
  const { text, keyboard } = generateProductList(page);
  ctx.editMessageText(text, keyboard);
});

// === Pilih produk - Show variations or details ===
bot.action(/SEL_\d+/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[0].split('_')[1]);
  const p = products[idx];
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  const st = S(ctx.chat.id);
  st.selected = { idx, code: p.code };

  // Check if product has variations
  if (p.variations && p.variations.length > 0) {
    showProductVariations(ctx, p, idx);
  } else {
    // No variations, show simple selection
    showSimpleProduct(ctx, p, idx);
  }
});

function showProductVariations(ctx, p, idx) {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  
  let text = `┌─────────────────────┐
│ *Produk:* ${escapeMarkdown(p.name)}
│ *Stok Terjual:* ${p.sold || 0}
│ *Desk:* ${escapeMarkdown(p.desc || 'Private, S&K: premiumisme.co')}
└─────────────────────┘

┌─────────────────────┐
│ *Variasi, Harga & Stok:*`;

  p.variations.forEach((v) => {
    const stock = v.accounts ? v.accounts.filter(a => !a.used).length : 0;
    text += `\n│ • ${escapeMarkdown(v.name)}: ${idr(v.price)} - Stok: ${stock}`;
  });
  
  text += `\n└─────────────────────┘

↻ Refresh at *${timeStr} WIB*`;

  const buttons = [];
  const row = [];
  p.variations.forEach((v, i) => {
    row.push(Markup.button.callback(`${v.name} - ${idr(v.price)}`, `VAR_${idx}_${i}`));
    if (row.length === 2) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  
  buttons.push([Markup.button.callback('🔄 Refresh', `REFRESH_PROD_${idx}`)]);
  buttons.push([Markup.button.callback('⬅️ Back', 'BACK_TO_LIST')]);

  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
}

function showSimpleProduct(ctx, p, idx) {
  const st = S(ctx.chat.id);
  
  // Check if stock is available
  const availableStock = p.accounts ? p.accounts.filter(a => !a.used).length : 0;
  
  if (availableStock === 0) {
    const text = `❌ *STOK HABIS*\n\nProduk: ${escapeMarkdown(p.name)}\nMaaf, produk ini sedang tidak tersedia.\n\nSilakan pilih produk lain.`;
    const kb = Markup.inlineKeyboard([[Markup.button.callback('⬅️ Kembali ke List', 'BACK_TO_LIST')]]);
    return ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
  }
  
  st.qty = 1;
  st.paymentMethod = 'QRIS';
  showOrderConfirmation(ctx, p, null, 1);
}

// Handle variation selection
bot.action(/VAR_(\d+)_(\d+)/, async (ctx) => {
  try { await ctx.answerCbQuery(); } catch (e) { /* ignore timeout */ }
  const [_, prodIdx, varIdx] = ctx.match[0].match(/VAR_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const variation = p.variations[varIdx];
  
  if (!variation) return ctx.reply('Variasi tidak ditemukan.');
  
  // Check if variation has stock
  const availableStock = variation.accounts ? variation.accounts.filter(a => !a.used).length : 0;
  
  if (availableStock === 0) {
    const text = `❌ *STOK HABIS*\n\nProduk: ${escapeMarkdown(p.name)}\nVariasi: ${escapeMarkdown(variation.name)}\nMaaf, variasi ini sedang tidak tersedia.\n\nSilakan pilih variasi lain.`;
    await ctx.reply(text, { parse_mode: 'Markdown' });
    return;
  }
  
  const st = S(ctx.chat.id);
  st.selected = { idx: prodIdx, code: p.code, varIdx, variation };
  st.qty = 1;
  st.paymentMethod = 'QRIS'; // default
  
  showOrderConfirmation(ctx, p, variation, 1);
});

// Refresh product info
bot.action(/REFRESH_PROD_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx, 'Diperbarui!');
  const idx = Number(ctx.match[0].split('_')[2]);
  const p = products[idx];
  if (!p) return;
  
  if (p.variations && p.variations.length > 0) {
    showProductVariations(ctx, p, idx);
  }
});

// Order confirmation with quantity adjustment
function showOrderConfirmation(ctx, product, variation, qty) {
  const st = S(ctx.chat.id);
  const now = new Date();
  const timeStr = now.toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  
  const price = variation ? variation.price : product.price;
  const varName = variation ? variation.name : 'Standard';
  const stock = variation ? 
    (variation.accounts ? variation.accounts.filter(a => !a.used).length : 0) :
    (product.stock || 0);
  
  const totalPrice = price * qty;
  
  let text = `╔═══════════════════════╗
║  KONFIRMASI PESANAN 🛒
╚═══════════════════════╝

┌───────────────────────┐
│ • Produk: ${escapeMarkdown(product.name)}
│ • Variasi: ${escapeMarkdown(varName)}
│ • Harga Satuan: Rp. ${idr(price)}
│ • Stok Tersedia: ${stock}
├───────────────────────┤
│ • Jumlah Pesanan: x${qty}
│ • Total Pembayaran: Rp. ${idr(totalPrice)}
└───────────────────────┘`;

  // Add warning if stock is low or qty equals stock
  if (qty === stock) {
    text += `\n\n⚠️ *Anda memesan semua stok yang tersedia!*`;
  } else if (stock <= 5) {
    text += `\n\n⚠️ *Stok terbatas: ${stock} tersisa*`;
  }
  
  text += `\n\n💡 *Atur jumlah pesanan dengan tombol +/- di bawah*\n\n↻ Refresh at *${timeStr} WIB*`;

  const buttons = [];
  
  // First row: -1 and +1 (only show +1 if not at max stock)
  const row1 = [Markup.button.callback('➖ 1', 'QTY_ADJ_-1')];
  if (qty < stock) {
    row1.push(Markup.button.callback('➕ 1', 'QTY_ADJ_+1'));
  }
  buttons.push(row1);
  
  // Second row: -5 and +5 (only show +5 if stock allows)
  const row2 = [Markup.button.callback('➖ 5', 'QTY_ADJ_-5')];
  if (qty + 5 <= stock) {
    row2.push(Markup.button.callback('➕ 5', 'QTY_ADJ_+5'));
  }
  buttons.push(row2);
  
  // Payment buttons
  const userBalance = userManager.getBalance(ctx.chat.id);
  const canPayWithSaldo = userBalance >= totalPrice;
  
  if (canPayWithSaldo) {
    buttons.push([
      Markup.button.callback('💳 BAYAR DENGAN QRIS', 'PAY_QRIS'),
      Markup.button.callback('💰 BAYAR DENGAN SALDO', 'PAY_SALDO')
    ]);
  } else {
    buttons.push([Markup.button.callback('💳 BAYAR DENGAN QRIS', 'PAY_QRIS')]);
    buttons.push([Markup.button.callback(`💰 Saldo (Rp${idr(userBalance)}) - Tidak Cukup`, 'SALDO_INSUFFICIENT')]);
  }
  
  buttons.push([Markup.button.callback('🔄 Refresh', 'REFRESH_ORDER')]);
  buttons.push([Markup.button.callback('⬅️ Kembali', `SEL_${st.selected.idx}`)]);

  if (ctx.callbackQuery) {
    ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
  } else {
    ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
  }
}

// Quantity adjustment handlers
bot.action(/QTY_ADJ_([+-]\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const adjustment = Number(ctx.match[1]);
  const st = S(ctx.chat.id);
  
  if (!st.selected) return ctx.reply('Silakan pilih produk terlebih dahulu.');
  
  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  
  // Calculate new quantity
  const newQty = Math.max(1, (st.qty || 1) + adjustment);
  
  // Check stock availability
  const availableStock = variation ? 
    (variation.accounts ? variation.accounts.filter(a => !a.used).length : 0) :
    (p.stock || 0);
  
  if (newQty > availableStock) {
    await ctx.answerCbQuery(`⚠️ Stok tidak cukup! Tersedia: ${availableStock}`, { show_alert: true });
    return;
  }
  
  st.qty = newQty;
  showOrderConfirmation(ctx, p, variation, st.qty);
});

// Payment with QRIS
bot.action('PAY_QRIS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.paymentMethod = 'QRIS';
  
  if (!st.selected) return ctx.reply('Silakan pilih produk terlebih dahulu.');
  
  // Proceed to payment
  await processPayment(ctx);
});

// Payment with Saldo
bot.action('PAY_SALDO', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.paymentMethod = 'SALDO';
  
  if (!st.selected) return ctx.reply('Silakan pilih produk terlebih dahulu.');
  
  // Proceed to payment with saldo
  await processPaymentWithSaldo(ctx);
});

// Saldo insufficient handler
bot.action('SALDO_INSUFFICIENT', async (ctx) => {
  const userBalance = userManager.getBalance(ctx.chat.id);
  await ctx.answerCbQuery(`Saldo Anda: Rp${idr(userBalance)}\nSilakan top up saldo atau gunakan QRIS.`, { show_alert: true });
});

bot.action('REFRESH_ORDER', async (ctx) => {
  await safeAnswerCbQuery(ctx, 'Diperbarui!');
  const st = S(ctx.chat.id);
  
  if (!st.selected) return ctx.reply('Silakan pilih produk terlebih dahulu.');
  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  
  showOrderConfirmation(ctx, p, variation, st.qty || 1);
});

// Handle back to list
bot.action('BACK_TO_LIST', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  const page = st.currentPage || 1;
  const { text, keyboard } = generateProductList(page);
  ctx.editMessageText(text, keyboard);
});

// === Process Payment with Saldo ===
async function processPaymentWithSaldo(ctx) {
  const chatId = ctx.chat.id;
  const st = S(chatId);
  
  if (!st?.selected || !st?.qty) {
    return ctx.reply('Silakan pilih produk & jumlah terlebih dahulu.');
  }

  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  const qty = st.qty;
  
  // Check stock availability
  let availableStock;
  let accountsSource;
  
  if (variation && p.variations && p.variations[st.selected.varIdx]) {
    accountsSource = p.variations[st.selected.varIdx];
    accountsSource.accounts = accountsSource.accounts || [];
    availableStock = accountsSource.accounts.filter(a => !a.used).length;
  } else {
    accountsSource = p;
    p.accounts = p.accounts || [];
    availableStock = p.accounts.filter(a => !a.used).length;
  }
  
  if (qty > availableStock) {
    return ctx.reply(`❌ *STOK TIDAK CUKUP!*\n\nProduk: ${escapeMarkdown(p.name)}\nDiminta: ${qty}\nTersedia: ${availableStock}\n\nSilakan kurangi jumlah pesanan.`, { parse_mode: 'Markdown' });
  }
  
  // Calculate price (no fee for saldo payment)
  const totalPrice = variation ? (variation.price * qty) : (p.price * qty);
  const productName = variation ? `${p.name} - ${variation.name}` : p.name;
  
  // Check user balance
  const userBalance = userManager.getBalance(chatId);
  
  if (userBalance < totalPrice) {
    return ctx.reply(`❌ *SALDO TIDAK CUKUP!*\n\nSaldo Anda: Rp${idr(userBalance)}\nTotal Pembayaran: Rp${idr(totalPrice)}\nKurang: Rp${idr(totalPrice - userBalance)}\n\nSilakan top up saldo atau gunakan QRIS.`, { parse_mode: 'Markdown' });
  }
  
  // Show confirmation
  const confirmText = `💰 *KONFIRMASI PEMBAYARAN DENGAN SALDO*\n\n` +
    `Produk: ${escapeMarkdown(productName)}\n` +
    `Jumlah: ${qty}\n` +
    `Total: Rp${idr(totalPrice)}\n\n` +
    `Saldo Anda: Rp${idr(userBalance)}\n` +
    `Saldo Setelah: Rp${idr(userBalance - totalPrice)}\n\n` +
    `Lanjutkan pembayaran?`;
  
  const confirmKb = Markup.inlineKeyboard([
    [
      Markup.button.callback('✅ Ya, Bayar', 'CONFIRM_SALDO_PAY'),
      Markup.button.callback('❌ Batal', 'CANCEL_SALDO_PAY')
    ]
  ]);
  
  ctx.editMessageText(confirmText, { parse_mode: 'Markdown', ...confirmKb });
}

// Confirm Saldo Payment
bot.action('CONFIRM_SALDO_PAY', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const chatId = ctx.chat.id;
  const st = S(chatId);
  
  if (!st?.selected || !st?.qty) {
    return ctx.reply('Silakan pilih produk & jumlah terlebih dahulu.');
  }

  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  const qty = st.qty;
  
  // Re-check stock availability
  let accountsSource;
  
  if (variation && p.variations && p.variations[st.selected.varIdx]) {
    accountsSource = p.variations[st.selected.varIdx];
    accountsSource.accounts = accountsSource.accounts || [];
  } else {
    accountsSource = p;
    p.accounts = p.accounts || [];
  }
  
  const available = accountsSource.accounts.filter((a) => !a.used);
  
  if (available.length < qty) {
    return ctx.editMessageText(`❌ *STOK TIDAK CUKUP!*\n\nMaaf, stok berkurang saat Anda melakukan konfirmasi.\nTersedia: ${available.length}\nDiminta: ${qty}`, { parse_mode: 'Markdown' });
  }
  
  // Calculate price
  const totalPrice = variation ? (variation.price * qty) : (p.price * qty);
  const productName = variation ? `${p.name} - ${variation.name}` : p.name;
  
  // Deduct balance
  const user = userManager.reduceBalance(chatId, totalPrice, `Pembelian ${productName} x${qty}`);
  
  if (!user) {
    return ctx.editMessageText(`❌ *SALDO TIDAK CUKUP!*\n\nTerjadi kesalahan saat mengurangi saldo.\nSilakan coba lagi.`, { parse_mode: 'Markdown' });
  }
  
  // Mark accounts as used and prepare delivery
  const send = available.slice(0, qty);
  send.forEach((a) => (a.used = true));
  
  // Update stock count
  if (variation && p.variations && p.variations[st.selected.varIdx]) {
    p.variations[st.selected.varIdx].stock = p.variations[st.selected.varIdx].accounts.filter(a => !a.used).length;
  }
  saveProducts();
  
  // Generate transaction ID
  const now = new Date();
  const dateStr = now.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '');
  const ref = `SALDO_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const transactionId = `VS-${dateStr}-${ref.split('_')[2].toUpperCase()}`;
  
  // Create success message
  let text = `╔═══════════════════════╗
║  PEMBAYARAN BERHASIL ✅
╚═══════════════════════╝

┌───────────────────────┐
│ • Ref: ${ref}
│ • Produk: ${escapeMarkdown(productName)}
│ • Jumlah Akun: ${qty}
│ • Total: Rp${idr(totalPrice)}
│ • Metode: Saldo
│ • Saldo Tersisa: Rp${idr(user.balance)}
└───────────────────────┘

🎉 *Terima kasih atas pembelian Anda!*

📦 *Detail Akun Anda:*
━━━━━━━━━━━━━━━━━━━━━

`;

  text += send
    .map(
      (a, i) =>
        `🔐 *Akun #${i + 1}*\n📧 Email: \`${a.email || '-'}\`\n🔑 Password: \`${a.password || '-'}\`\n📝 Deskripsi: ${escapeMarkdown(a.desc || '-')}`
    )
    .join('\n\n━━━━━━━━━━━━━━━━━━━━━\n\n');

  text += `\n\n━━━━━━━━━━━━━━━━━━━━━\n\n⚠️ *Penting:*\n• Simpan data akun dengan aman\n• Jangan bagikan ke orang lain\n• Hubungi admin jika ada masalah\n\n✨ Terima kasih telah berbelanja!`;

  try {
    await ctx.editMessageText(text, { 
      parse_mode: 'Markdown',
      disable_web_page_preview: true 
    });
  } catch (err) {
    console.error('Error sending SALDO payment confirmation:', err.message);
    // Fallback: try to send as new message
    try {
      await ctx.reply(text, { 
        parse_mode: 'Markdown',
        disable_web_page_preview: true 
      });
    } catch (err2) {
      console.error('Error sending fallback message:', err2.message);
    }
  }
  
  // Clear session
  st.selected = null;
  st.qty = null;
  st.paymentMethod = null;
});

// Cancel Saldo Payment
bot.action('CANCEL_SALDO_PAY', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  
  if (!st.selected) return ctx.reply('Silakan pilih produk terlebih dahulu.');
  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  
  showOrderConfirmation(ctx, p, variation, st.qty || 1);
});

// === Process Payment (with variations support) ===
async function processPayment(ctx) {
  const chatId = ctx.chat.id;
  const st = S(chatId);
  
  if (!st?.selected || !st?.qty) {
    return ctx.reply('Silakan pilih produk & jumlah terlebih dahulu.');
  }

  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  const qty = st.qty;
  
  // CRITICAL: Check stock availability before creating invoice
  let availableStock;
  let accountsSource;
  
  if (variation && p.variations && p.variations[st.selected.varIdx]) {
    accountsSource = p.variations[st.selected.varIdx];
    accountsSource.accounts = accountsSource.accounts || [];
    availableStock = accountsSource.accounts.filter(a => !a.used).length;
  } else {
    accountsSource = p;
    p.accounts = p.accounts || [];
    availableStock = p.accounts.filter(a => !a.used).length;
  }
  
  if (qty > availableStock) {
    return ctx.reply(`❌ *STOK TIDAK CUKUP!*\n\nProduk: ${escapeMarkdown(p.name)}\nDiminta: ${qty}\nTersedia: ${availableStock}\n\nSilakan kurangi jumlah pesanan.`, { parse_mode: 'Markdown' });
  }
  
  // Determine price and product details
  const baseTotal = variation ? (variation.price * qty) : (p.price * qty);
  const serviceFee = Math.round(baseTotal * FEE_PERCENT) + FEE_FIXED;
  const totalCharge = baseTotal + serviceFee;
  
  const productName = variation ? `${p.name} - ${variation.name}` : p.name;
  const ref = `ORD_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  try {
    const inv = await atlantic.createQrisInvoice({ amount: totalCharge, ref_id: ref });
    const data = inv && (inv.data || inv) ? (inv.data || inv) : {};

    const invoice_id = data.invoice_id || data.id;
    const reff_id = data.reff_id || data.ref_id;
    const qris_image = data.qris_image || data.image_url || data.qrImage || data.qr_url;
    const qris_string = data.qris_string || data.qr_string || data.qrString || data.qr || data.qr_content;

    const now = new Date();
    const expiresAt = new Date(now.getTime() + PAYMENT_TTL_MS);

    if (!invoice_id) {
      await ctx.reply('Invoice dibuat, namun ID tidak terdeteksi. Pantau pembayaran manual.');
      return;
    }

    // Store invoice record FIRST before sending messages
    pending.set(invoice_id, {
      msgIds: new Set(),
      chatId,
      ref,
      reff_id,
      code: p.code,
      qty,
      baseTotal,
      serviceFee,
      totalCharge,
      note: `Pembelian ${productName} x${qty}`,
      createdAt: now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      productName,
      variation: variation || null,
      varIdx: st.selected.varIdx
    });

    // 1) Kirim QR dan track message
    const qrMsg = await sendQrisImage(ctx, {
      qris_string,
      qris_image,
      invoice_id,
      ref,
      total_charge: totalCharge
    });
    trackInvoiceMsg(invoice_id, qrMsg);

    // 2) Generate transaction ID in format similar to image
    const dateStr = now.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '');
    const transactionId = `VS-${dateStr}-${ref.split('_')[2].toUpperCase()}`;

    // 3) Kirim konfirmasi dengan format yang lebih menarik
    const varName = variation ? variation.name : 'Standard';
    const confirmText = `╔═══════════════════════╗
║  PESANAN TERKONFIRMASI ✅
╚═══════════════════════╝

┌───────────────────────┐
│ • Produk: ${escapeMarkdown(productName)}
│ • Variasi: ${escapeMarkdown(varName)}
│ • Harga Satuan: Rp. ${idr(baseTotal / qty)}
│ • ID Transaksi:
│   ${transactionId}
├───────────────────────┤
│ • Jumlah Pesanan: x${qty}
│ • Total Pembayaran: Rp. ${idr(totalCharge)}
└───────────────────────┘

💳 *Pembayaran kadaluwarsa dalam 5 menit.*
⚡ Silakan scan QRIS untuk menyelesaikan pembayaran!

⏰ Pembayaran dibuat: ${fmtWIB(now)}
⌛ Kadaluwarsa pada: ${fmtWIB(expiresAt)}`;

    const cancelButton = Markup.inlineKeyboard([
      [Markup.button.callback('❌ Batalkan Order', `CANCEL_ORDER_${invoice_id}`)]
    ]);

    const pendMsg = await ctx.reply(confirmText, { parse_mode: 'Markdown', ...cancelButton });
    trackInvoiceMsg(invoice_id, pendMsg);
  } catch (e) {
    console.error('createQrisInvoice error:', e?.message || e);
    await ctx.reply('Gagal membuat invoice: ' + (e?.message || e));
  }
}


// === Handle Cancel Order Button ===
bot.action(/CANCEL_ORDER_(.+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const invoice_id = ctx.match[1];
  const payload = pending.get(invoice_id);
  
  if (!payload) {
    return ctx.editMessageText('❌ Invoice tidak ditemukan atau sudah diproses.');
  }
  
  if (payload.chatId !== ctx.chat.id) {
    return ctx.answerCbQuery('⛔ Ini bukan pesanan Anda!', { show_alert: true });
  }
  
  try {
    // Try to cancel the invoice via API
    if (typeof atlantic.cancelInvoice === 'function') {
      await atlantic.cancelInvoice({ invoice_id, reff_id: payload.reff_id });
    }
  } catch (e) {
    console.log('Cancel invoice error:', e?.message || e);
  }
  
  // Delete all invoice messages
  await deleteInvoiceMessages(payload.chatId, invoice_id);
  
  // Remove from pending
  pending.delete(invoice_id);
  
  // Send cancellation confirmation
  await ctx.reply(`✅ *Pesanan Dibatalkan*\n\nInvoice: ${invoice_id}\nProduk: ${escapeMarkdown(payload.productName)}\nTotal: Rp. ${idr(payload.totalCharge)}\n\nPesanan Anda telah dibatalkan.`, { parse_mode: 'Markdown' });
});

// === Process QRIS Top Up ===
async function processQrisTopup(ctx, amount) {
  const chatId = ctx.chat.id;
  
  // Calculate total with fees
  const serviceFee = Math.round(amount * FEE_PERCENT) + FEE_FIXED;
  const totalCharge = amount + serviceFee;
  
  const ref = `TOPUP_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  
  try {
    const inv = await atlantic.createQrisInvoice({ amount: totalCharge, ref_id: ref });
    const data = inv && (inv.data || inv) ? (inv.data || inv) : {};
    
    const invoice_id = data.invoice_id || data.id;
    const reff_id = data.reff_id || data.ref_id;
    const qris_image = data.qris_image || data.image_url || data.qrImage || data.qr_url;
    const qris_string = data.qris_string || data.qr_string || data.qrString || data.qr || data.qr_content;
    
    const now = new Date();
    const expiresAt = new Date(now.getTime() + PAYMENT_TTL_MS);
    
    if (!invoice_id) {
      await ctx.reply('Invoice dibuat, namun ID tidak terdeteksi. Silakan coba lagi.');
      return;
    }
    
    // Store topup QRIS record
    topupQris.set(invoice_id, {
      msgIds: new Set(),
      chatId,
      ref,
      reff_id,
      amount, // Amount user will receive (excluding fees)
      totalCharge,
      serviceFee,
      createdAt: now.toISOString(),
      expiresAt: expiresAt.toISOString()
    });
    
    // Send QR Code
    const qrMsg = await sendQrisImage(ctx, {
      qris_string,
      qris_image,
      invoice_id,
      ref,
      total_charge: totalCharge
    });
    
    if (topupQris.has(invoice_id) && qrMsg) {
      topupQris.get(invoice_id).msgIds.add(qrMsg.message_id);
    }
    
    // Send confirmation
    const confirmText = `╔═══════════════════════╗
║  TOP UP VIA QRIS ⚡
╚═══════════════════════╝

┌───────────────────────┐
│ • Jumlah Top Up: Rp${idr(amount)}
│ • Biaya Admin: Rp${idr(serviceFee)}
│ • Total Bayar: Rp${idr(totalCharge)}
│ • ID Transaksi: ${ref}
└───────────────────────┘

💳 *Scan QR Code di atas untuk membayar*

⚡ Saldo akan masuk OTOMATIS setelah pembayaran!

⏰ Dibuat: ${fmtWIB(now)}
⌛ Kadaluwarsa: ${fmtWIB(expiresAt)}

⚠️ Waktu pembayaran: 5 menit`;
    
    const cancelButton = Markup.inlineKeyboard([
      [Markup.button.callback('❌ Batalkan Top Up', `CANCEL_TOPUP_${invoice_id}`)]
    ]);
    
    const pendMsg = await ctx.reply(confirmText, { parse_mode: 'Markdown', ...cancelButton });
    
    if (topupQris.has(invoice_id) && pendMsg) {
      topupQris.get(invoice_id).msgIds.add(pendMsg.message_id);
    }
  } catch (e) {
    console.error('createQrisInvoice error:', e?.message || e);
    await ctx.reply('Gagal membuat invoice top up: ' + (e?.message || e));
  }
}

// Cancel QRIS Topup
bot.action(/CANCEL_TOPUP_(.+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const invoice_id = ctx.match[1];
  const payload = topupQris.get(invoice_id);
  
  if (!payload) {
    return ctx.editMessageText('❌ Invoice tidak ditemukan atau sudah diproses.');
  }
  
  if (payload.chatId !== ctx.chat.id) {
    return ctx.answerCbQuery('⛔ Ini bukan top up Anda!', { show_alert: true });
  }
  
  try {
    if (typeof atlantic.cancelInvoice === 'function') {
      await atlantic.cancelInvoice({ invoice_id, reff_id: payload.reff_id });
    }
  } catch (e) {
    console.log('Cancel invoice error:', e?.message || e);
  }
  
  // Delete messages
  for (const mid of payload.msgIds) {
    try { await bot.telegram.deleteMessage(payload.chatId, mid); } catch {}
  }
  
  topupQris.delete(invoice_id);
  
  await ctx.reply(`✅ *Top Up Dibatalkan*\n\nInvoice: ${invoice_id}\nJumlah: Rp${idr(payload.amount)}\n\nTop up Anda telah dibatalkan.`, { parse_mode: 'Markdown' });
});

// === Polling status & Auto-cancel 5 menit ===
setInterval(async () => {
  const now = Date.now();
  
  // Poll QRIS topup payments
  for (const [invoice_id, payload] of topupQris.entries()) {
    try {
      const res = await atlantic.getInvoiceStatus({ invoice_id, reff_id: payload.reff_id });
      const status = res?.data?.status || 'PENDING';
      
      // Auto-cancel if expired
      const exp = new Date(payload.expiresAt).getTime();
      if (now > exp && status !== 'PAID') {
        try {
          if (typeof atlantic.cancelInvoice === 'function') {
            await atlantic.cancelInvoice({ invoice_id, reff_id: payload.reff_id });
          }
        } catch {}
        
        // Delete messages
        for (const mid of payload.msgIds) {
          try { await bot.telegram.deleteMessage(payload.chatId, mid); } catch {}
        }
        
        await bot.telegram.sendMessage(
          payload.chatId,
          `⏰ Waktu pembayaran top up habis. Invoice ${invoice_id} dibatalkan.`
        );
        topupQris.delete(invoice_id);
        continue;
      }
      
      if (status === 'PAID') {
        const { chatId, ref, amount } = payload;
        
        // Add balance to user
        const user = userManager.addBalance(chatId, amount, `Top up via QRIS - ${ref}`);
        
        // Delete QR messages
        for (const mid of payload.msgIds) {
          try { await bot.telegram.deleteMessage(chatId, mid); } catch {}
        }
        
        // Send success message
        const text = `╔═══════════════════════╗
║  TOP UP BERHASIL ✅
╚═══════════════════════╝

┌───────────────────────┐
│ • Ref: ${ref}
│ • Jumlah: Rp${idr(amount)}
│ • Saldo Baru: Rp${idr(user.balance)}
│ • Metode: QRIS
└───────────────────────┘

🎉 *Top up berhasil!*
Saldo Anda telah ditambahkan.

✨ Terima kasih!`;
        
        await bot.telegram.sendMessage(chatId, text, { parse_mode: 'Markdown' });
        
        try {
          if (typeof atlantic.instantDeposit === 'function') {
            await atlantic.instantDeposit({ invoice_id });
          }
        } catch {}
        
        topupQris.delete(invoice_id);
      }
      
      if (['EXPIRED', 'CANCELLED'].includes(status)) {
        for (const mid of payload.msgIds) {
          try { await bot.telegram.deleteMessage(payload.chatId, mid); } catch {}
        }
        await bot.telegram.sendMessage(
          payload.chatId,
          `ℹ️ Top up invoice ${invoice_id} berstatus ${status}.`
        );
        topupQris.delete(invoice_id);
      }
    } catch {}
  }
  
  // Poll product orders
  for (const [invoice_id, payload] of pending.entries()) {
    try {
      const res = await atlantic.getInvoiceStatus({ invoice_id, reff_id: payload.reff_id });
      const status = res?.data?.status || 'PENDING';

      // Auto-cancel jika lewat TTL dan belum paid
      const exp = new Date(payload.expiresAt).getTime();
      if (now > exp && status !== 'PAID') {
        try {
          if (typeof atlantic.cancelInvoice === 'function') {
            await atlantic.cancelInvoice({ invoice_id, reff_id: payload.reff_id });
          }
        } catch {}
        await deleteInvoiceMessages(payload.chatId, invoice_id);
        await bot.telegram.sendMessage(
          payload.chatId,
          `⏰ Waktu pembayaran habis. Invoice ${invoice_id} dibatalkan.`
        );
        pending.delete(invoice_id);
        continue;
      }

      if (status === 'PAID') {
        const { chatId, ref, code, qty, variation, varIdx } = payload;
        const p = products.find((x) => x.code === code);
        if (!p) { pending.delete(invoice_id); continue; }

        // Get accounts from variation or main product
        let accountsSource;
        let productDisplayName;
        
        if (variation && p.variations && p.variations[varIdx]) {
          accountsSource = p.variations[varIdx];
          productDisplayName = `${p.name} - ${variation.name}`;
        } else {
          accountsSource = p;
          productDisplayName = p.name;
        }

        accountsSource.accounts = accountsSource.accounts || [];
        const available = accountsSource.accounts.filter((a) => !a.used);
        
        if (available.length < qty) {
          const msg = `⚠️ PAID tapi stok kurang untuk ${productDisplayName}. Dibutuhkan ${qty}, tersedia ${available.length}. Ref: ${ref}`;
          (ADMIN_IDS || []).forEach((id) => bot.telegram.sendMessage(id, msg).catch(() => {}));
          continue;
        }

        const send = available.slice(0, qty);
        send.forEach((a) => (a.used = true));
        
        // Update stock count
        if (variation && p.variations && p.variations[varIdx]) {
          p.variations[varIdx].stock = p.variations[varIdx].accounts.filter(a => !a.used).length;
        }
        saveProducts();

        // Delete QR and pending messages
        await deleteInvoiceMessages(chatId, invoice_id);

        // Create beautiful success message
        let text = `╔═══════════════════════╗
║  PEMBAYARAN BERHASIL ✅
╚═══════════════════════╝

┌───────────────────────┐
│ • Ref: ${ref}
│ • Produk: ${escapeMarkdown(productDisplayName)}
│ • Jumlah Akun: ${qty}
│ • Total: Rp. ${idr(payload.totalCharge)}
└───────────────────────┘

🎉 *Terima kasih atas pembelian Anda!*

📦 *Detail Akun Anda:*
━━━━━━━━━━━━━━━━━━━━━\n\n`;

        text += send
          .map(
            (a, i) =>
              `🔐 *Akun #${i + 1}*\n📧 Email: \`${a.email || '-'}\`\n🔑 Password: \`${a.password || '-'}\`\n📝 Deskripsi: ${escapeMarkdown(a.desc || '-')}`
          )
          .join('\n\n━━━━━━━━━━━━━━━━━━━━━\n\n');

        text += `\n\n━━━━━━━━━━━━━━━━━━━━━\n\n⚠️ *Penting:*\n• Simpan data akun dengan aman\n• Jangan bagikan ke orang lain\n• Hubungi admin jika ada masalah\n\n✨ Terima kasih telah berbelanja!`;

        try {
          await bot.telegram.sendMessage(chatId, text, { 
            parse_mode: 'Markdown',
            disable_web_page_preview: true 
          });
        } catch (err) {
          console.error('Error sending QRIS payment confirmation:', err.message);
        }

        try {
          if (typeof atlantic.instantDeposit === 'function') {
            await atlantic.instantDeposit({ invoice_id });
          }
        } catch {}
        pending.delete(invoice_id);
      }

      if (['EXPIRED', 'CANCELLED'].includes(status)) {
        await deleteInvoiceMessages(payload.chatId, invoice_id);
        await bot.telegram.sendMessage(
          payload.chatId,
          `ℹ️ Invoice ${invoice_id} berstatus ${status}.`
        );
        pending.delete(invoice_id);
      }
    } catch {
      // abaikan cycle ini
    }
  }
}, 5000);

// === Global Error Handlers for VPS Stability ===
// Prevent bot crashes from unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('⚠️ Unhandled Promise Rejection:', reason);
  console.error('Promise:', promise);
  // Don't exit, keep bot running
});

// Prevent bot crashes from uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('⚠️ Uncaught Exception:', error);
  // Don't exit, keep bot running
});

// Bot-level error handler
bot.catch((err, ctx) => {
  console.error('⚠️ Bot Error:', err);
  try {
    if (ctx && ctx.reply) {
      ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi atau hubungi admin.').catch(console.error);
    }
  } catch (e) {
    console.error('Error sending error message:', e);
  }
});

module.exports = bot;
