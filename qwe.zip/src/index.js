const bot = require('./enhanced_bot');

// Launch bot with error handling
bot.launch()
  .then(() => {
    console.log('✅ Bot started successfully!');
    console.log('⏰ Time:', new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }));
    console.log('🤖 Bot is now running 24/7...');
    
    // Heartbeat log every hour
    setInterval(() => {
      console.log('💓 Bot heartbeat:', new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }));
    }, 60 * 60 * 1000); // Every 1 hour
  })
  .catch((err) => {
    console.error('❌ Failed to start bot:', err);
    process.exit(1);
  });

// Graceful shutdown handlers
process.once('SIGINT', () => {
  console.log('⚠️ SIGINT received, stopping bot...');
  bot.stop('SIGINT');
});

process.once('SIGTERM', () => {
  console.log('⚠️ SIGTERM received, stopping bot...');
  bot.stop('SIGTERM');
});