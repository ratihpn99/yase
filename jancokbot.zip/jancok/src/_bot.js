
const { Telegraf, Markup } = require('telegraf');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');
const atlantic = require('./atlanticClient');
const { BOT_TOKEN, ADMIN_IDS } = require('./config');

if (!BOT_TOKEN) throw new Error('BOT_TOKEN belum diisi di .env');

const productsPath = path.join(__dirname, 'products.json');
let products = [];
try { products = JSON.parse(fs.readFileSync(productsPath, 'utf8')); } catch(e){ products = []; }

function saveProducts(){
  products.forEach(p => {
    p.accounts = p.accounts || [];
    p.stock = p.accounts.filter(a => !a.used).length;
  });
  fs.writeFileSync(productsPath, JSON.stringify(products, null, 2), 'utf8');
}

function isAdmin(id){
  if (!Array.isArray(ADMIN_IDS)) return false;
  return ADMIN_IDS.map(x=>String(x)).includes(String(id));
}

const bot = new Telegraf(BOT_TOKEN);
const session = new Map();
const pending = new Map(); // invoice_id -> { chatId, ref, reff_id, code, qty }
function S(chatId){ if(!session.has(chatId)) session.set(chatId, {}); return session.get(chatId); }

bot.start((ctx) => {
  const kb = Markup.inlineKeyboard([[Markup.button.callback('📦 List Produk', 'LIST_PROD')]]);
  ctx.reply('Halo! Selamat datang 👋', kb);
});

bot.action('LIST_PROD', async (ctx) => {
  await ctx.answerCbQuery();
  if (products.length===0) return ctx.editMessageText('Belum ada produk.');
  const lines = products.map((p,i)=> `${i+1}. ${p.name} — ${p.price} (stok: ${p.stock||0})`);
  const btns = products.map((p,i)=> Markup.button.callback(String(i+1), `SEL_${i}`));
  const rows = [];
  for (let i=0;i<btns.length;i+=5) rows.push(btns.slice(i,i+5));
  ctx.editMessageText('Daftar produk:\n\n'+lines.join('\n'), Markup.inlineKeyboard(rows));
});

bot.action(/SEL_\d+/, async (ctx) => {
  await ctx.answerCbQuery();
  const idx = Number(ctx.match[0].split('_')[1]);
  const p = products[idx];
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  const st = S(ctx.chat.id);
  st.selected = { idx, code: p.code };
  const text = `*${p.name}*\nHarga: ${p.price}\nStok: ${p.stock||0}\n${p.desc||''}\n\nPilih jumlah akun:`;
  const qtyBtns = [[1,2,3,4,5].map(n=>Markup.button.callback(String(n), `QTY_${n}`))];
  ctx.editMessageText(text, { parse_mode:'Markdown', ...Markup.inlineKeyboard(qtyBtns) });
});

bot.action(/QTY_\d+/, async (ctx) => {
  await ctx.answerCbQuery();
  const qty = Number(ctx.match[0].split('_')[1]);
  const st = S(ctx.chat.id);
  if (!st.selected) return ctx.reply('Silakan pilih produk dahulu.');
  const p = products[st.selected.idx];
  if ((p.stock||0) < qty) return ctx.editMessageText(`Stok kurang. Stok: ${p.stock||0}`);
  st.qty = qty;
  const txt = `Konfirmasi:\nProduk: ${p.name}\nQty: ${qty}\nTotal: *${p.price*qty}*\n\nKlik untuk bayar via QRIS.`;
  const kb = Markup.inlineKeyboard([[Markup.button.callback('💳 Pay now via QRIS','PAY_NOW')],[Markup.button.callback('⬅️ Kembali','LIST_PROD')]]);
  ctx.editMessageText(txt, { parse_mode:'Markdown', ...kb });
});

bot.action('PAY_NOW', async (ctx) => {
  await ctx.answerCbQuery();
  const chatId = ctx.chat.id;
  const st = S(chatId);
  if (!st?.selected || !st?.qty) return ctx.reply('Silakan pilih produk & jumlah terlebih dahulu.');
  const p = products[st.selected.idx];
  const total = p.price * st.qty;
  const ref = `ORD_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
  try {
    const inv = await atlantic.createQrisInvoice({ amount: total, ref_id: ref });
    const { invoice_id, reff_id, qris_string, qris_image } = inv.data;
    pending.set(invoice_id, { chatId, ref, reff_id, code: p.code, qty: st.qty });
    if (qris_image) {
      await ctx.replyWithPhoto(qris_image, { caption: `Invoice: ${invoice_id}\nRef: ${ref}\nNominal: ${total}` });
    } else if (qris_string) {
      const png = await QRCode.toBuffer(qris_string, { scale: 8 });
      await ctx.replyWithPhoto({ source: png }, { caption: `Invoice: ${invoice_id}\nRef: ${ref}\nNominal: ${total}` });
    } else {
      await ctx.reply(`Invoice: ${invoice_id}\nRef: ${ref}\nNominal: ${total}`);
    }
    await ctx.reply('Setelah transfer, sistem akan otomatis memproses.');
  } catch (e) {
    await ctx.reply('Gagal membuat invoice: ' + e.message);
  }
});

bot.command('products', (ctx) => {
  const lines = products.map(p => `${p.code} — ${p.name}\nHarga: ${p.price}\nStok: ${p.stock||0}`);
  ctx.reply(lines.length?lines.join('\n\n'):'Belum ada produk.');
});

bot.command('add_product', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const json = ctx.message.text.split(/\s+/).slice(1).join(' ');
  if (!json) return ctx.reply('Usage: /add_product {"code":"CODE","name":"Name","price":10000,"desc":"..."}');
  try {
    const obj = JSON.parse(json);
    obj.code = String(obj.code||'').toUpperCase();
    obj.accounts = obj.accounts || [];
    products.push(obj);
    saveProducts();
    ctx.reply(`Produk ${obj.code} ditambahkan.`);
  } catch(e){ ctx.reply('JSON tidak valid: '+e.message); }
});

bot.command('delete_product', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const code = (ctx.message.text.split(/\s+/)[1]||'').toUpperCase();
  const idx = products.findIndex(p=>p.code===code);
  if (idx===-1) return ctx.reply('Produk tidak ditemukan.');
  products.splice(idx,1);
  saveProducts();
  ctx.reply(`Produk ${code} dihapus.`);
});

bot.command('add_account', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const parts = ctx.message.text.split(/\s+/).slice(1);
  if (parts.length < 2) return ctx.reply('Usage: /add_account <CODE> {"email":"..","password":"..","desc":".."}');
  const code = parts[0].toUpperCase();
  const json = parts.slice(1).join(' ');
  const p = products.find(x=>x.code===code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  try{
    const acc = JSON.parse(json);
    if (!acc.email || !acc.password) return ctx.reply('email & password wajib.');
    p.accounts = p.accounts || [];
    p.accounts.push({ ...acc, used:false });
    saveProducts();
    ctx.reply(`Akun ditambahkan. Stok ${code}: ${p.stock}`);
  }catch(e){ ctx.reply('JSON tidak valid: '+e.message); }
});

bot.command('remove_account', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const parts = ctx.message.text.split(/\s+/).slice(1);
  if (parts.length < 2) return ctx.reply('Usage: /remove_account <CODE> <index>');
  const code = parts[0].toUpperCase();
  const idx = parseInt(parts[1],10);
  const p = products.find(x=>x.code===code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  p.accounts = p.accounts || [];
  if (isNaN(idx) || !p.accounts[idx]) return ctx.reply('Index akun tidak valid.');
  p.accounts.splice(idx,1);
  saveProducts();
  ctx.reply(`Akun dihapus. Stok ${code}: ${p.stock}`);
});

bot.command('list_accounts', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const code = (ctx.message.text.split(/\s+/)[1]||'').toUpperCase();
  const p = products.find(x=>x.code===code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  p.accounts = p.accounts || [];
  if (!p.accounts.length) return ctx.reply('Belum ada akun.');
  const lines = p.accounts.map((a,i)=> `${i}. ${a.email} | ${a.used?'USED':'idle'} | ${a.desc||''}`);
  ctx.reply(lines.join('\n'));
});

bot.command('set_price', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const parts = ctx.message.text.split(/\s+/).slice(1);
  if (parts.length < 2) return ctx.reply('Usage: /set_price <CODE> <price>');
  const code = parts[0].toUpperCase();
  const price = parseInt(parts[1],10);
  const p = products.find(x=>x.code===code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  if (isNaN(price)) return ctx.reply('price harus angka');
  p.price = price;
  saveProducts();
  ctx.reply(`Harga ${code} diupdate ke ${price}`);
});

bot.command('set_desc', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const parts = ctx.message.text.split(/\s+/).slice(1);
  if (parts.length < 2) return ctx.reply('Usage: /set_desc <CODE> <desc...>');
  const code = parts[0].toUpperCase();
  const desc = parts.slice(1).join(' ');
  const p = products.find(x=>x.code===code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  p.desc = desc;
  saveProducts();
  ctx.reply(`Deskripsi ${code} diperbarui.`);
});

setInterval(async () => {
  for (const [invoice_id, payload] of pending.entries()) {
    try {
      const res = await atlantic.getInvoiceStatus({ invoice_id, reff_id: payload.reff_id });
      const status = res?.data?.status || 'PENDING';
      if (status === 'PAID') {
        const { chatId, ref, code, qty } = payload;
        const p = products.find(x=>x.code===code);
        p.accounts = p.accounts || [];
        const available = p.accounts.filter(a=>!a.used);
        if (available.length < qty) {
          const msg = `⚠️ PAID tapi stok kurang untuk ${code}. Dibutuhkan ${qty}, tersedia ${available.length}. Ref: ${ref}`;
          (ADMIN_IDS||[]).forEach(id => bot.telegram.sendMessage(id, msg).catch(()=>{}));
          continue;
        }
        const send = available.slice(0, qty);
        send.forEach(a => a.used = true);
        saveProducts();
        let text = `✅ Pembayaran diterima.\nRef: ${ref}\nProduk: ${p.name}\nJumlah akun: ${qty}\n\n`;
        text += send.map((a,i)=> `Akun #${i+1}\nEmail: ${a.email}\nPassword: ${a.password}\nDeskripsi: ${a.desc||''}`).join('\n\n');
        await bot.telegram.sendMessage(chatId, text);
        try { await atlantic.instantDeposit({ invoice_id }); } catch(e){}
        pending.delete(invoice_id);
      }
      if (['EXPIRED','CANCELLED'].includes(status)) pending.delete(invoice_id);
    } catch(e){ /* ignore this cycle */ }
  }
}, 15000);

module.exports = bot;
