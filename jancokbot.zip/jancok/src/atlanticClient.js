
const axios = require('axios');
const { ATLANTIC } = require('./config');

const api = axios.create({ baseURL: ATLANTIC.BASE_URL, timeout: 20000 });

function toForm(data) {
  const p = new URLSearchParams();
  Object.entries(data).forEach(([k, v]) => v !== undefined && p.append(k, String(v)));
  return p;
}
function envPath(name, def) { return (process.env[name] || '').trim() || def; }
function fullPath(p){ return p.startsWith('/') ? p : `/${p}`; }

module.exports = {
  async createQrisInvoice({ amount, ref_id }) {
    const path = fullPath(envPath('ATLANTIC_CREATE_PATH', '/deposit/create'));
    const payload = toForm({
      api_key: ATLANTIC.API_KEY,
      reff_id: ref_id,
      nominal: parseInt(amount,10),
      type: 'ewallet',
      metode: 'qris'
    });
    try {
      const { data } = await api.post(path, payload, {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      });
      const r = data || {};
      if (r?.status !== true) throw new Error('Create invoice failed: ' + JSON.stringify(r).slice(0,400));
      const d = r.data || {};
      if (!d?.id) throw new Error('No invoice id returned');
      return {
        success: true,
        message: 'OK',
        data: {
          invoice_id: d.id,
          reff_id: d.reff_id || ref_id,
          qris_string: d.qr_string,
          qris_image: d.qr_image,
          raw: r
        }
      };
    } catch (e) {
      const status = e?.response?.status;
      const url = (e?.config?.baseURL || ATLANTIC.BASE_URL) + (e?.config?.url || path);
      const body = e?.response?.data;
      const msg = typeof body === 'string' ? body : JSON.stringify(body);
      throw new Error(`HTTP ${status||'?'} at ${url}: ${msg||e.message}`);
    }
  },

  async getInvoiceStatus({ invoice_id, reff_id }) {
    const path = fullPath(envPath('ATLANTIC_STATUS_PATH', '/deposit/status'));
    const attempts = [
      toForm({ api_key: ATLANTIC.API_KEY, id: invoice_id }),
      toForm({ api_key: ATLANTIC.API_KEY, reff_id })
    ];
    let r=null,lastErr=null;
    for(const payload of attempts){
      try{
        const { data } = await api.post(path, payload, { headers: { 'Content-Type':'application/x-www-form-urlencoded' } });
        r = data || {};
        break;
      }catch(e){ lastErr = e; }
    }
    if (!r) throw lastErr;
    const d = r.data || {};
    const st = (d.status || r.status || '').toString().toLowerCase();
    let status = 'PENDING';
    if (['success','paid','settled','done'].includes(st)) status='PAID';
    if (['expired','timeout'].includes(st)) status='EXPIRED';
    if (['failed','cancelled','canceled'].includes(st)) status='CANCELLED';
    return { success:true, message:'OK', data:{ status, raw:r } };
  },

  async instantDeposit({ invoice_id }) {
    const path = fullPath(envPath('ATLANTIC_INSTANT_PATH', '/deposit/instant'));
    const payload = toForm({ api_key: ATLANTIC.API_KEY, id: invoice_id, action: 'true' });
    const { data } = await api.post(path, payload, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });
    return { success:true, data };
  }
};
